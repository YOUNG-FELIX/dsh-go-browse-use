/* dsh-go-browse-use / MV3 service worker 入口
 *
 * 只做三件事：
 *   1. 先把 browser.* 的 Promise 语义垫上（polyfill.js）
 *   2. importScripts 引入 config.js / eval-host.js / mark.js / background.js
 *   3. SW 被系统回收后由 background.js 里已注册的 bb-keepalive 闹钟唤醒，
 *      唤醒即重新执行本文件 → background.js 末尾的 loop() 自动续跑。
 *
 * background.js 与 Firefox 版是同一份文件，没有任何 Chromium 专用分支。
 * 不同的有两份：
 *   - eval-host.js：MV3 的 scripting.executeScript 没有 code 参数，
 *     要在页面里跑字符串就绕不开求值，所以那份实现在 Chromium 侧；
 *     Firefox 用 tabs.executeScript({code})，源码里一个求值调用都不用留，
 *     AMO 的 addons-linter 因此不会报 DANGEROUS_EVAL。
 *   - mark.js：动画 favicon 的做法。Firefox 支持渲染动画 GIF，直接用；
 *     Chromium 只画 GIF 第一帧（老 bug），所以那边改成帧序列逐帧换 favicon。
 */
'use strict';
importScripts('polyfill.js', 'config.js', 'eval-host.js', 'mark.js', 'background.js');
