/* dsh-go-browse-use / chromium polyfill
 * 许可：MIT License（Copyright (c) 2026 dsh-go-browse-use contributors），全文见随包 LICENSE。
 *
 * Chromium 只有 chrome.* 且大多数 API 是回调式；本项目后台代码全部按
 * browser.* 的 Promise 语义写。这里在 SW 启动最早一刻把 browser 顶出来，
 * 这样 background.js / options.js 一行都不用改。
 *
 * 没定义 tabs.executeScript —— 让它保持 undefined，background.js 的
 * inPage() 就会自己走 MV3 的 scripting.executeScript 分支。
 */
(function () {
  const C = globalThis.chrome;
  if (!C) return;
  /* 有些 Chromium 分支（Vivaldi/Edge 的某些版本）把 browser 直接指到 chrome 本身。
   * 那种情况下往 B 上写方法 = 覆盖 chrome 自己的方法，包装器再调 obj[method]
   * 就调回自己 —— 无限递归，报 "Maximum call stack size exceeded"。
   * 所以：只要 browser 和 chrome 是同一个对象，就另起一个干净对象，绝不动 chrome。 */
  const existing = globalThis.browser;
  const B = (existing && existing !== C) ? existing : (globalThis.browser = {});

  const lastErr = () => (C.runtime && C.runtime.lastError) || null;

  /* 回调式 API → Promise */
  function cbify(obj, method) {
    /* 关键：在包装那一刻就把原函数抓住。运行时再查 obj[method] 的话，
     * 一旦那个属性后来被我们自己覆盖（或 obj 就是 chrome），就会自我递归。 */
    const fn = obj[method];
    return function (...args) {
      const self = obj;
      return new Promise((resolve, reject) => {
        try {
          fn.call(self, ...args, (r) => {
            const e = lastErr();
            if (e) reject(new Error(e.message));
            else resolve(r);
          });
        } catch (err) {
          reject(err);
        }
      });
    };
  }

  /* 同步 / 已支持 Promise 的 API */
  function plain(obj, method) {
    const fn = obj[method];
    return function (...args) {
      try {
        const r = fn.apply(obj, args);
        return r && typeof r.then === 'function' ? r : Promise.resolve(r);
      } catch (err) {
        return Promise.reject(err);
      }
    };
  }

  function copyEvents(src, dst, keys) {
    for (const k of keys) {
      if (src && src[k] !== undefined && dst[k] === undefined) dst[k] = src[k];
    }
  }

  /* ---- storage ---- */
  const S = C.storage;
  if (S) {
    B.storage = B.storage || {};
    for (const area of ['local', 'sync', 'session', 'managed']) {
      if (!S[area]) continue;
      B.storage[area] = {
        get: cbify(S[area], 'get'),
        set: cbify(S[area], 'set'),
        remove: cbify(S[area], 'remove'),
        clear: cbify(S[area], 'clear'),
      };
    }
    copyEvents(S, B.storage, ['onChanged']);
  }

  /* ---- tabs ---- */
  if (C.tabs) {
    B.tabs = B.tabs || {};
    for (const m of ['query', 'get', 'create', 'update', 'remove', 'reload', 'captureVisibleTab', 'sendMessage', 'duplicate']) {
      if (typeof C.tabs[m] === 'function') B.tabs[m] = cbify(C.tabs, m);
    }
    copyEvents(C.tabs, B.tabs, ['onActivated', 'onUpdated', 'onRemoved', 'onCreated']);
    /* 故意不定义 executeScript：MV2 API，MV3 里应走 scripting */
  }

  /* ---- cookies / history / bookmarks ---- */
  if (C.cookies) {
    B.cookies = B.cookies || {};
    B.cookies.getAll = cbify(C.cookies, 'getAll');
    B.cookies.getAllCookieStores = cbify(C.cookies, 'getAllCookieStores');
    copyEvents(C.cookies, B.cookies, ['onChanged']);
  }
  if (C.history) {
    B.history = B.history || {};
    for (const m of ['search', 'getVisits', 'deleteUrl']) {
      if (typeof C.history[m] === 'function') B.history[m] = cbify(C.history, m);
    }
  }
  if (C.bookmarks) {
    B.bookmarks = B.bookmarks || {};
    for (const m of ['search', 'getRecent', 'get', 'getTree']) {
      if (typeof C.bookmarks[m] === 'function') B.bookmarks[m] = cbify(C.bookmarks, m);
    }
    copyEvents(C.bookmarks, B.bookmarks, ['onCreated', 'onRemoved']);
  }

  /* ---- scripting（MV3 的注入通道）---- */
  if (C.scripting) {
    B.scripting = { executeScript: cbify(C.scripting, 'executeScript') };
  }

  /* ---- alarms ---- */
  if (C.alarms) {
    B.alarms = {
      create: plain(C.alarms, 'create'),
      clear: plain(C.alarms, 'clear'),
      get: cbify(C.alarms, 'get'),
    };
    copyEvents(C.alarms, B.alarms, ['onAlarm']);
  }

  /* ---- runtime ---- */
  if (C.runtime) {
    B.runtime = B.runtime || {};
    for (const m of ['sendMessage', 'getPlatformInfo', 'requestUpdateCheck', 'sendNativeMessage']) {
      if (typeof C.runtime[m] === 'function') B.runtime[m] = cbify(C.runtime, m);
    }
    for (const m of ['openOptionsPage', 'setUninstallURL', 'reload']) {
      if (typeof C.runtime[m] === 'function') B.runtime[m] = plain(C.runtime, m);
    }
    /* 这两个在 Firefox 里是同步返回字符串/对象的，包成 Promise 会把调用方写坏 */
    if (typeof C.runtime.getManifest === 'function') B.runtime.getManifest = () => C.runtime.getManifest();
    if (typeof C.runtime.getURL === 'function') B.runtime.getURL = (p) => C.runtime.getURL(p);
    copyEvents(C.runtime, B.runtime, ['onStartup', 'onInstalled', 'onMessage', 'onConnect', 'onSuspend', 'onUpdateAvailable']);
    if (B.runtime.id === undefined) B.runtime.id = C.runtime.id;
  }

  /* ---- 工具栏按钮：MV2 browserAction → MV3 action ---- */
  const A = C.action || C.browserAction;
  if (A) {
    B.browserAction = B.browserAction || {};
    for (const m of ['setBadgeText', 'setBadgeBackgroundColor', 'setTitle', 'setIcon', 'enable', 'disable']) {
      if (typeof A[m] === 'function') B.browserAction[m] = cbify(A, m);
    }
    B.browserAction.onClicked = A.onClicked;
    B.action = B.browserAction;
  }

  /* ---- permissions / idle 之类按需直通 ---- */
  if (C.permissions) {
    B.permissions = { request: cbify(C.permissions, 'request'), contains: cbify(C.permissions, 'contains') };
  }
})();
