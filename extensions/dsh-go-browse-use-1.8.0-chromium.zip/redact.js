'use strict';
/*
 * browser-bridge / redact.js
 *
 * 出站脱敏层。所有要回传给桥接的数据都先过这里。
 * 目的：即使桥接侧被日志、被别的进程读到，也不含完整身份信息。
 *
 * 默认全开。调用方可以按命令关掉：
 *   { cmd: 'cookies.get', args: { raw: true } }
 *
 * 注意：这是「降低暴露面」，不是「保证不可还原」。
 * 掩码规则是确定性的，知道规则就能推回一部分（如手机号前 3 后 4）。
 * 真要拿原值，只能显式传 raw:true —— 那一步是有意的。
 */

const RULES = [
  // 身份证：18 位，保留前 6（地区码）后 4
  { name: 'idcard', re: /\b(\d{6})(\d{8})(\d{3}[\dXx])\b/g, to: (m, a, b, c) => `${a}********${c}` },

  // 银行卡：16-19 位连续数字，保留后 4
  { name: 'bankcard', re: /\b(\d{12,15})(\d{4})\b/g, to: (m, a, b) => `${'*'.repeat(a.length)}${b}` },

  // 手机号（中国大陆）：保留前 3 后 4
  { name: 'phone', re: /\b(1[3-9]\d)\d{4}(\d{4})\b/g, to: (m, a, b) => `${a}****${b}` },

  // 邮箱：保留首字母 + 域名
  { name: 'email', re: /\b([A-Za-z0-9._%+-])[A-Za-z0-9._%+-]*(@[A-Za-z0-9.-]+\.[A-Za-z]{2,})\b/g, to: (m, a, b) => `${a}***${b}` },

  // 键值对里的敏感字段
  { name: 'kv', re: /\b(password|passwd|pwd|secret|token|apikey|api_key|api-key|authorization|auth|session|sessionid|csrf|xsrf|otp|pin|cvv)\b(\s*[:=]\s*)(["']?)([^\s"',;}\]]{3,})/gi,
    to: (m, k, sep, q, v) => `${k}${sep}${q}${'*'.repeat(Math.min(v.length, 12))}` },

  // 长 base64 / JWT 串（可能是凭据）
  { name: 'jwt', re: /\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\b/g, to: () => 'eyJ***.***.***' },

  // 疑似私钥
  { name: 'privkey', re: /-----BEGIN [A-Z ]*PRIVATE KEY-----[\s\S]{20,}?-----END [A-Z ]*PRIVATE KEY-----/g,
    to: () => '-----BEGIN PRIVATE KEY----- [REDACTED] -----END PRIVATE KEY-----' },
];

/** 对单个字符串做脱敏 */
function redactString(s, opts) {
  if (typeof s !== 'string' || !s) return s;
  const enabled = (opts && opts.rules) || null;
  let out = s;
  for (const r of RULES) {
    if (enabled && !enabled.includes(r.name)) continue;
    out = out.replace(r.re, r.to);
  }
  return out;
}

/** 递归脱敏任意结构里的所有字符串；数字不动（避免破坏坐标等） */
function redactDeep(v, opts, depth) {
  depth = depth || 0;
  if (depth > 12) return '[too deep]';
  if (typeof v === 'string') return redactString(v, opts);
  if (v === null || typeof v !== 'object') return v;
  if (Array.isArray(v)) return v.map((x) => redactDeep(x, opts, depth + 1));
  const o = {};
  for (const k of Object.keys(v)) {
    // 键名本身也可能带敏感信息（如 cookie 名），脱敏值即可
    o[k] = redactDeep(v[k], opts, depth + 1);
  }
  return o;
}

/**
 * 主入口：给一条命令的结果做脱敏。
 * skip: 完全不处理的命令（值本身已是掩码，或必须原样用于操作）
 */
const SKIP = new Set(['ping', 'tabs.list', 'tab.get']);

function redactResult(cmd, data, opts) {
  const o = opts || {};
  if (o.raw === true) return { data, redacted: false, note: 'raw:true 已关闭脱敏' };
  if (o.redact === false) return { data, redacted: false, note: 'redact:false 已关闭脱敏' };
  if (SKIP.has(cmd)) return { data, redacted: false };
  return { data: redactDeep(data, o), redacted: true };
}

/** 掩码一个 cookie 值，保留首尾各 2 字符便于比对 */
function maskCookieValue(v) {
  const s = String(v == null ? '' : v);
  if (s.length <= 4) return '*'.repeat(s.length || 1);
  if (s.length <= 12) return s.slice(0, 1) + '*'.repeat(s.length - 2) + s.slice(-1);
  return s.slice(0, 2) + '*'.repeat(Math.min(s.length - 4, 24)) + s.slice(-2) + `[len ${s.length}]`;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { redactString, redactDeep, redactResult, maskCookieValue, RULES };
}