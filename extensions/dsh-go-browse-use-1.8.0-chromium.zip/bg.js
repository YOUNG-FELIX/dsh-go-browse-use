/* browser-bridge / MV3 service worker 入口
 *
 * 只做三件事：
 *   1. 先把 browser.* 的 Promise 语义垫上（polyfill.js）
 *   2. importScripts 引入与 Firefox 版完全相同的 config.js / background.js
 *   3. SW 被系统回收后由 background.js 里已注册的 bb-keepalive 闹钟唤醒，
 *      唤醒即重新执行本文件 → background.js 末尾的 loop() 自动续跑。
 *
 * 因此 background.js 与 Firefox 版是同一份文件，没有任何 Chromium 专用分支。
 */
'use strict';
importScripts('polyfill.js', 'config.js', 'background.js');
