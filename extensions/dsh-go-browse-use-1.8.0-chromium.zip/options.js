'use strict';
/* browser-bridge / options.js
 *
 * 设置页：显示桥接状态 + 输入配对码。这是 Android 上唯一可靠的入口
 * （Firefox for Android 没有工具栏图标，browserAction 按钮藏在菜单里）。
 */

const $ = (id) => document.getElementById(id);

const E = {
  state: $('state'),
  port: $('port'),
  health: $('health'),
  paired: $('paired'),
  served: $('served'),
  sid: $('sid'),
  pairBox: $('pairBox'),
  doneBox: $('doneBox'),
  helpBox: $('helpBox'),
  code: $('code'),
  go: $('go'),
  msg: $('msg'),
  msg2: $('msg2'),
  unpair: $('unpair'),
};

function setState(text, tone) {
  E.state.textContent = text;
  E.state.className = 'state ' + (tone || '');
}

async function getToken() {
  try {
    const o = await browser.storage.local.get([BB_PAIRED_KEY]);
    return o[BB_PAIRED_KEY] || null;
  } catch (_) {
    return null;
  }
}

async function getHealth() {
  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), 4000);
  try {
    const r = await fetch(BB_BASE + '/health', { cache: 'no-store', signal: ctl.signal });
    return r.ok ? await r.json() : null;
  } catch (_) {
    return null;
  } finally {
    clearTimeout(t);
  }
}

/* 跟后台说话。带超时：消息通道一旦不回话就立刻给出可读结果，
 * 不再把按钮钉死在「配对中…」上。 */
function askBackground(type, payload) {
  const ask = browser.runtime.sendMessage(Object.assign({ type }, payload || {}))
    .catch((e) => ({ ok: false, error: (e && e.message) || String(e) }));
  return Promise.race([
    ask,
    new Promise((r) => setTimeout(() => r({ ok: false, error: '后台没回话（消息通道 6 秒无响应）' }), 6000)),
  ]);
}

/* 配对直接在本页做 —— 不经过后台的消息通道。
 * 设置页本来就能直接 fetch 桥接（健康检查就是这么做的），
 * 绕开 sendMessage 就少一个能把流程卡死的环节。 */
async function pairDirect(code) {
  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), 8000);
  try {
    const r = await fetch(BB_BASE + '/pair', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ code: String(code).trim(), sid: 'opt' }),
      cache: 'no-store',
      signal: ctl.signal,
    });
    const j = await r.json().catch(() => ({}));
    if (!r.ok || !j.token) throw new Error(j.error || ('pair http ' + r.status));
    await browser.storage.local.set({ [BB_PAIRED_KEY]: j.token });
    // 让后台重新读令牌并开始轮询；不等回话，否则又会被同一个通道拖住
    browser.runtime.sendMessage({ type: 'bb-reload' }).catch(() => {});
    return j;
  } catch (e) {
    if (e && e.name === 'AbortError') throw new Error('桥接 8 秒没回话（开关可能关着）');
    throw e;
  } finally {
    clearTimeout(t);
  }
}

async function refresh() {
  E.port.textContent = String(BB_PORT);
  const [tok, h] = await Promise.all([getToken(), getHealth()]);

  E.health.textContent = h ? '有响应' : '没响应';
  E.health.className = h ? 'ok' : 'bad';
  E.served.textContent = h ? String(h.served) : '—';
  E.sid.textContent = (h && h.sid) || '—';

  const paired = !!tok;
  E.paired.textContent = paired ? '已配对' : '未配对';
  E.paired.className = paired ? 'ok' : 'warn';

  E.pairBox.hidden = paired;
  E.doneBox.hidden = !paired;

  if (!h) {
    setState('⚠️ 桥接没响应（开关可能关着）', 'warn');
    E.helpBox.hidden = false;
  } else if (!paired) {
    setState('⚠️ 还没配对', 'warn');
    E.helpBox.hidden = false;
  } else if (h.online) {
    setState('✅ 已连接', 'ok');
    E.helpBox.hidden = true;
  } else {
    setState('⚠️ 已配对，等待扩展轮询', 'warn');
    E.helpBox.hidden = false;
  }

  if (!paired) {
    setTimeout(() => { try { E.code.focus(); } catch (_) {} }, 100);
  }
}

E.go.addEventListener('click', async () => {
  const code = (E.code.value || '').replace(/\D/g, '');
  if (code.length !== 6) {
    E.msg.className = 'msg bad';
    E.msg.textContent = '需要 6 位数字';
    return;
  }
  E.go.disabled = true;
  E.go.textContent = '配对中…';
  E.msg.className = 'msg';
  E.msg.textContent = '';
  let r;
  try {
    await pairDirect(code);
    r = { ok: true };
  } catch (e) {
    r = { ok: false, error: (e && e.message) || String(e) };
  }
  E.go.disabled = false;
  E.go.textContent = '配对';
  if (r && r.ok) {
    E.msg.className = 'msg ok';
    E.msg.textContent = '配对成功';
    setTimeout(refresh, 400);
  } else {
    E.msg.className = 'msg bad';
    E.msg.textContent = '失败：' + ((r && r.error) || '未知原因');
    E.code.select();
  }
});

E.code.addEventListener('keydown', (ev) => {
  if (ev.key === 'Enter') E.go.click();
});
E.code.addEventListener('input', () => {
  E.code.value = E.code.value.replace(/\D/g, '').slice(0, 6);
});

E.unpair.addEventListener('click', async () => {
  E.unpair.disabled = true;
  await askBackground('bb-unpair');
  E.unpair.disabled = false;
  E.msg2.className = 'msg';
  E.msg2.textContent = '已解除配对';
  setTimeout(refresh, 300);
});

refresh();
setInterval(refresh, 5000);