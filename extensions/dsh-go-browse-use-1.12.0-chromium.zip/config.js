/* dsh-go-browse-use 连接配置
 *
 * 不再把令牌写死在包里 —— 每个安装实例在首次运行时向桥接换一对唯一令牌，
 * 存在浏览器本地 storage 里。这样同一个 xpi 装到不同机器上，令牌各不相同。
 */
const BB_PORT = 8790;
const BB_HOST = '127.0.0.1';
const BB_BASE = `http://${BB_HOST}:${BB_PORT}`;

/* 首次安装时你在扩展里输入桥接终端显示的 6 位配对码。
 * 留空则扩展会尝试读一次桥接的 /health，若桥接没开就等你点开状态页输入。
 */
const BB_PAIRED_KEY = 'bb_token';
const BB_SID_KEY = 'bb_sid';