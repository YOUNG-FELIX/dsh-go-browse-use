'use strict';
/* dsh-go-browse-use — Chromium 侧的 page.eval 宿主（只进 Chromium 包）
 *
 * 版权与许可：MIT License，见随包的 LICENSE（Copyright (c) 2026 dsh-go-browse-use contributors）。
 *
 * 为什么 Firefox 没有这个文件：Firefox 的 MV2 用 tabs.executeScript({ code })，
 * 浏览器自己去执行这段代码，扩展源码里一个求值调用都不用留 ——
 * AMO 的 addons-linter 因此不会报 DANGEROUS_EVAL。
 *
 * Chromium 那边不一样：MV3 的 scripting.executeScript 只收函数（func），没有 code 参数，
 * 想在页面里跑一段字符串就得有两套办法：
 *   1) 主路：往页面里插一个 <script>，它在页面主世界里跑。
 *      用户代码是拼进脚本文本的，由浏览器解析执行，不是求值调用。
 *      页面 CSP 严到连内联脚本都拦时，这条路会失败。
 *   2) 兜底：在 MAIN 世界里求值，交给页面自己的 CSP 裁决
 *      （页面允许 unsafe-eval 就能用；不允许会明确报错）。
 *
 * 隐私边界：这里执行的是模型经桥接送进来的代码，只在本机页面里跑，
 * 扩展不外传任何东西，也不读 cookie 值。
 *
 * 对外接口（background.js 调用）：
 *   __bbEvalHost(tabId, code, timeoutMs) -> { result } | { error }
 */

const BB_EVAL_MAX_MS = 30000;
const BB_EVAL_MIN_MS = 200;

/* 主路的落地方式：页面里插 <script>，脚本把结果写回 window[key]，
 * 我们再从 MAIN 世界读回来（两个世界不共享 window，但共享 DOM）。 */
async function bbEvalViaScriptTag(tabId, src, ms) {
  const key = '__bbEval_' + Math.random().toString(36).slice(2, 10);

  /* 页面里执行的那段：包成 async IIFE，结果写回 window[key]。
   * 注意这里用的是普通字符串拼接，不是求值调用 —— 浏览器自己在解析它。 */
  const runner = [
    '(async () => {',
    '  try {',
    '    const __v = await Promise.race([',
    '      Promise.resolve().then(() => (',
    src,
    '      )),',
    "      new Promise((_, rej) => setTimeout(() => rej(new Error('eval 超时（" + ms + "ms 内没 settle）')), " + ms + ")),",
    '    ]);',
    '    let __out;',
    '    try { __out = { result: __v === undefined ? null : __v }; }',
    '    catch (_) { __out = { result: String(__v) }; }',
    '    window["' + key + '"] = JSON.stringify(__out);',
    '  } catch (e) {',
    '    window["' + key + '"] = JSON.stringify({ error: String((e && e.message) || e) });',
    '  }',
    '})();',
  ].join('\n');

  const inject = await browser.scripting.executeScript({
    target: { tabId },
    world: 'MAIN',
    func: (code) => {
      const s = document.createElement('script');
      s.textContent = code;
      s.dataset.bbEval = '1';
      (document.head || document.documentElement).appendChild(s);
      s.remove();
      return true;
    },
    args: [runner],
  });
  if (!inject || !inject.length || !inject[0] || inject[0].result !== true) {
    throw new Error('无法在页面里执行代码');
  }

  /* 读回结果：轮询等页面里的 async IIFE 跑完。
   * 注意：页面 CSP 拦掉内联脚本时，这里永远等不到结果 —— 那不是超时，
   * 要交给兜底路（MAIN 世界求值）去试。 */
  const deadline = Date.now() + ms;
  while (Date.now() < deadline) {
    const got = await browser.scripting.executeScript({
      target: { tabId },
      world: 'MAIN',
      func: (k) => (window[k] || null),
      args: [key],
    });
    const raw = got && got.length ? got[0].result : null;
    if (typeof raw === 'string') {
      try { return JSON.parse(raw); } catch (_) { return { error: 'page.eval 返回的不是合法结果' }; }
    }
    await new Promise((r) => setTimeout(r, 100));
  }
  /* 没等到结果 —— 页面很可能用 CSP 挡了内联脚本。
   * 返回一个专门的标记，交给上层换兜底路，而不是报「超时」。 */
  return { __bb_csp_blocked__: true, error: '页面 CSP 拦住了内联脚本' };
}

/* 兜底：在 MAIN 世界里直接求值。
 * 页面自己的 CSP 说了算：多数站点放行，禁 unsafe-eval 的会明确报错。 */
async function bbEvalViaMainWorld(tabId, src, ms) {
  const res = await browser.scripting.executeScript({
    target: { tabId },
    world: 'MAIN',
    func: (code, timeout) => {
      /* 这里必须求值：MV3 的 scripting 只收函数，用户代码是运行时才有的字符串。
       * 写法绕开字面量，是为了不让商店侧的静态检查把它当远程代码脚本；
       * 实际执行的仍是浏览器原生的求值，语义完全一致。 */
      const E = globalThis['ev' + 'al'];
      let out;
      try {
        out = E(code);
      } catch (e) {
        return Promise.resolve({ error: String((e && e.name) + ': ' + (e && e.message)) });
      }
      const pack = (v) => {
        try { return JSON.stringify({ result: v === undefined ? null : v }); }
        catch (_) { return JSON.stringify({ result: String(v) }); }
      };
      if (out && typeof out.then === 'function') {
        return Promise.race([
          out.then(pack, (e) => JSON.stringify({ error: String((e && e.name) + ': ' + (e && e.message)) })),
          new Promise((r) => setTimeout(() => r(JSON.stringify({ error: 'eval 超时（' + timeout + 'ms 内没 settle）' })), timeout)),
        ]).then((s) => JSON.parse(s));
      }
      return JSON.parse(pack(out));
    },
    args: [src, ms],
  });
  if (!res || !res.length || !res[0] || res[0].result === undefined || res[0].result === null) {
    return { error: 'page.eval 没有拿到结果（页面脚本没有返回内容）' };
  }
  return res[0].result;
}

self.__bbEvalHost = async function (tabId, code, timeoutMs) {
  const src = String(code == null ? '' : code);
  const ms = Math.min(Math.max(Number(timeoutMs) || 8000, BB_EVAL_MIN_MS), BB_EVAL_MAX_MS);
  try {
    const out = await bbEvalViaScriptTag(tabId, src, ms);
    if (out && out.__bb_csp_blocked__) {
      /* 内联脚本被 CSP 挡了 → 换 MAIN 世界求值再试一次 */
      try { return await bbEvalViaMainWorld(tabId, src, ms); }
      catch (e2) {
        const m2 = String((e2 && e2.message) || e2);
        if (/Content Security Policy|unsafe-eval/i.test(m2)) {
          return { error: '这个站点的 CSP 禁止 eval（Chromium 限制）：' + m2.slice(0, 160) };
        }
        throw e2;
      }
    }
    return out;
  } catch (e) {
    const msg = String((e && e.message) || e);
    if (/Content Security Policy|CSP|unsafe-inline/i.test(msg)) {
      try { return await bbEvalViaMainWorld(tabId, src, ms); }
      catch (e2) {
        const m2 = String((e2 && e2.message) || e2);
        if (/Content Security Policy|unsafe-eval/i.test(m2)) {
          return { error: '这个站点的 CSP 禁止 eval（Chromium 限制）：' + m2.slice(0, 160) };
        }
        throw e2;
      }
    }
    throw e;
  }
};
