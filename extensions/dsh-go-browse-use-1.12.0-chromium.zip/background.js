'use strict';
/*
 * dsh-go-browse-use — browser extension background worker
 * 版权与许可：MIT License，见随包的 LICENSE（Copyright (c) 2026 dsh-go-browse-use contributors）。
 *
 * 职责：在扩展侧执行命令。桥接进程（dsh-go 插件里的 bridge.cjs）长轮询本文件的命令队列，
 * 把一条条命令转成 browser.* 调用；结果回传给桥接，最后由 dsh-go 的工具层交给模型。
 *
 * 隐私边界（给分发审阅与后来人看的）：
 *  - 扩展只与 127.0.0.1 上的桥接通信；令牌由用户在扩展设置页输入配对码领取。
 *  - cookie 的「值」不经过扩展出站：cookies.get 只回元数据，cookies.jar 仅供用户导出到本地文件。
 *  - 读正文/截图等有内容外泄可能的命令，由桥接那侧按站点授权，扩展不自行判断放行。
 *  - 被控制的标签会加标题前缀与 favicon 标记（仅改 DOM，刷新即复原），见 fMark。
 *  - AI 正在用的那个标签额外有一条顶边流动光效（纯 CSS 装饰），见 fBar。
 */
/*
 * 历史：本文件早期称 browser-bridge / background.js（包名已改为 dsh-go-browse-use）
 *
 * 常驻后台，向 http://127.0.0.1:8790 长轮询取命令，执行完把结果回传。
 * 所有能力都走各标签页的 content 世界里执行，不回传任何数据到外网。
 *
 * 依赖：同目录 config.js 提供 BB_BASE，令牌在首次配对后存入 storage.local
 */

const SID = 'ff-' + Math.random().toString(36).slice(2, 10);
/* 扩展版本：跟着 /poll 报给桥接，面板上能直接看出是不是装了个旧的 */
const EXT_VER = (() => {
  try { return (browser.runtime.getManifest && browser.runtime.getManifest().version) || '?'; } catch (_) { return '?'; }
})();

/* 浏览器名：上报给桥接用于实例列表的显示名（不然面板上只有一串随机 sid）。
 * 优先用 Chromium 的 userAgentData.brands（能分出 Vivaldi/Edge/Chrome），
 * 退回去解析 UA，Firefox 的 UA 里带 Firefox/x.y。 */
const EXT_NAME = (() => {
  try {
    const ua = (typeof navigator !== 'undefined' && navigator.userAgent) || '';
    const brands = (typeof navigator !== 'undefined' && navigator.userAgentData && navigator.userAgentData.brands) || null;
    if (brands && brands.length) {
      const pick = ['Vivaldi', 'Microsoft Edge', 'Opera', 'Brave', 'Google Chrome', 'Chromium'];
      for (const want of pick) {
        const b = brands.find((x) => String(x.brand).includes(want));
        if (b) return b.brand.replace('Google ', '') + ' ' + String(b.version || '').split('.')[0];
      }
    }
    const m = /Firefox\/(\d+)/.exec(ua);
    if (m) return 'Firefox ' + m[1];
    const c = /Chrome\/(\d+)/.exec(ua);
    if (c) return 'Chrome ' + c[1];
    return ua ? 'Browser' : 'Extension';
  } catch (_) { return 'Extension'; }
})();

/* 工具栏角标：Firefox 安卓没有工具栏会被静默忽略，桌面 Chrome/Firefox 有效。
 * 未配对显示「!」，正常为空。不做成提醒弹窗，避免每次启动都骚扰。 */
function setBadge(txt, color) {
  try {
    if (!browser.browserAction || !browser.browserAction.setBadgeText) return;
    browser.browserAction.setBadgeText({ text: txt || '' });
    if (color && browser.browserAction.setBadgeBackgroundColor) {
      browser.browserAction.setBadgeBackgroundColor({ color });
    }
  } catch (_) { /* 安卓 Firefox 没有这个 API，忽略 */ }
}
const POLL_TIMEOUT = 30000;

let running = false;
let lastBeat = 0;
let TOKEN = null;

/* ---- 令牌：存 storage.local，每装一次唯一 ---- */
async function loadToken() {
  const o = await browser.storage.local.get([BB_PAIRED_KEY, BB_SID_KEY]);
  if (o[BB_SID_KEY] && o[BB_SID_KEY] !== SID) {
    // 会话号变了（浏览器重启），沿用同一令牌
  }
  TOKEN = o[BB_PAIRED_KEY] || null;
  setBadge(TOKEN ? '' : '!', TOKEN ? undefined : '#C0504D');
  return TOKEN;
}
async function saveToken(tok) {
  TOKEN = tok;
  await browser.storage.local.set({ [BB_PAIRED_KEY]: tok, [BB_SID_KEY]: SID });
}
async function clearToken() {
  TOKEN = null;
  await browser.storage.local.remove([BB_PAIRED_KEY, BB_SID_KEY]);
}
function hdr(extra) {
  return Object.assign({ 'x-bb-token': TOKEN || '', 'Content-Type': 'application/json' }, extra || {});
}

/* 首次自动配对：本机桥接还没有任何已信任实例时，装好就能直接连上。
 * 桥接只在「一个都还没配对」时接受这种请求，之后一律要配对码。 */
async function autoPair() {
  // 退避，避免桥接没起来时死循环打日志
  const now = Date.now();
  if (now - (autoPair.lastTry || 0) < 60000) return false;
  autoPair.lastTry = now;
  try {
    const r = await fetch(BB_BASE + '/pair', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ code: '', sid: SID, auto: true }),
      cache: 'no-store',
    });
    const j = await r.json().catch(() => ({}));
    if (r.ok && j.token) {
      await saveToken(j.token);
      note('自动配对成功', SID);
      return true;
    }
    note('自动配对未生效（可能已有实例配对过）', j && j.error);
    return false;
  } catch (e) {
    note('自动配对失败', e && e.message);
    return false;
  }
}

async function pair(code) {
  const r = await fetch(BB_BASE + '/pair', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ code: String(code).trim(), sid: SID }),
    cache: 'no-store',
  });
  const j = await r.json().catch(() => ({}));
  if (!r.ok || !j.token) throw new Error(j.error || ('pair http ' + r.status));
  await saveToken(j.token);
  return j;
}

/* 令牌轮换：拿旧令牌换新的，旧令牌当场作废。到期或收到 403 时自动走一次。 */
async function rotateToken() {
  if (!TOKEN) return false;
  try {
    const r = await fetch(BB_BASE + '/rotate', {
      method: 'POST',
      headers: hdr(),
      cache: 'no-store',
    });
    if (!r.ok) {
      // 403 = 旧令牌已失效（过期或被吊销），只能重新配对
      if (r.status === 403) { await clearToken(); note('令牌失效，需要重新配对'); }
      return false;
    }
    const j = await r.json().catch(() => ({}));
    if (j && j.token) { await saveToken(j.token); note('令牌已轮换'); return true; }
    return false;
  } catch (e) {
    return false;
  }
}

/* 诊断日志：既打 console，也落一份环形缓冲到 storage.local。
 * Android 上后台页随时可能被系统挂起，挂起后 console 就没了 ——
 * 不留一份在磁盘上，事后根本查不出「链路是什么时候断的、断在哪一步」。
 * 只记事件名和短参数，绝不记页面正文、cookie、令牌。 */
const DIAG_KEY = 'bb.diag';
const DIAG_MAX = 200;
let diagBuf = null;
function diagLoad() {
  if (diagBuf) return Promise.resolve(diagBuf);
  return browser.storage.local.get(DIAG_KEY).then((o) => {
    diagBuf = Array.isArray(o && o[DIAG_KEY]) ? o[DIAG_KEY] : [];
    return diagBuf;
  }, () => { diagBuf = []; return diagBuf; });
}
function diagPush(level, msg) {
  const line = { t: new Date().toISOString(), level, msg: String(msg == null ? '' : msg).slice(0, 300) };
  diagLoad().then((buf) => {
    buf.push(line);
    if (buf.length > DIAG_MAX) buf.splice(0, buf.length - DIAG_MAX);
    try { browser.storage.local.set({ [DIAG_KEY]: buf }); } catch (_) {}
  });
}
function note(...a) {
  lastBeat = Date.now();
  console.log('[bb]', ...a);
  diagPush('info', a.map((x) => (typeof x === 'string' ? x : (x && x.message) || String(x))).join(' '));
}

/* ---------- 与桥接通信 ---------- */

async function bbHealth() {
  const r = await fetch(BB_BASE + '/health', { headers: {}, cache: 'no-store' });
  return r.ok ? r.json() : null;
}

async function bbPoll() {
  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), POLL_TIMEOUT);
  try {
    const r = await fetch(`${BB_BASE}/poll?sid=${SID}&v=${encodeURIComponent(EXT_VER)}&n=${encodeURIComponent(EXT_NAME)}`, {
      headers: hdr(),
      cache: 'no-store',
      signal: ctl.signal,
    });
    if (r.status === 204) return null;
    if (r.status === 403) {
      // 可能只是过期：先试轮换，成功就重来一轮
      if (await rotateToken()) return null;
      const e = new Error('poll http 403（令牌失效）');
      e.auth = true;
      throw e;
    }
    if (!r.ok) throw new Error('poll http ' + r.status);
    return await r.json();
  } finally {
    clearTimeout(t);
  }
}

async function bbResult(id, ok, payload) {
  const body = ok
    ? { id, ok: true, data: payload }
    : { id, ok: false, error: String(payload && payload.message || payload) };
  try {
    await fetch(BB_BASE + '/result', {
      method: 'POST',
      headers: hdr(),
      body: JSON.stringify(body),
      cache: 'no-store',
    });
  } catch (e) {
    console.warn('[bb] result post failed', e.message);
  }
}

/* ---------- 工具 ---------- */

function activeTab() {
  return browser.tabs.query({ active: true, currentWindow: true }).then((ts) => {
    if (!ts || !ts.length) throw new Error('no active tab');
    return ts[0];
  });
}

function tabById(id) {
  return browser.tabs.get(id);
}

/* 等一个标签加载到指定状态。
 * 返回 {readyState, title, url, waitedMs, timedOut}。
 * timedOut=true 表示没等到（页面可能很慢或已经跳走）——
 * 这时调用方应该知道「跳转已经发起，但页面还没稳」，而不是当成失败。 */
async function waitTabLoaded(tabId, until, timeoutMs) {
  const want = String(until || 'load').toLowerCase();
  if (want === 'none') return { navigation: 'pending', readyState: null, waitedMs: 0, timedOut: false };
  const budget = Math.min(Number(timeoutMs) || 20000, 30000);
  const started = Date.now();
  /* 先看一次：页面可能秒开 */
  while (Date.now() - started < budget) {
    let t = null;
    try { t = await browser.tabs.get(tabId); } catch (_) { break; }
    const st = t && t.status;
    const ok = want === 'domcontentloaded'
      ? (st === 'complete' || st === 'loading' ? true : false)
      : st === 'complete';
    /* loading 也算 domcontentloaded 已过（DOM 已就绪） */
    if (ok) {
      return {
        navigation: 'done',
        readyState: st,
        title: t.title || '',
        url: t.url || '',
        waitedMs: Date.now() - started,
        timedOut: false,
      };
    }
    await new Promise((r) => setTimeout(r, 250));
  }
  let t = null;
  try { t = await browser.tabs.get(tabId); } catch (_) {}
  return {
    navigation: 'pending',
    readyState: (t && t.status) || null,
    title: (t && t.title) || '',
    url: (t && t.url) || '',
    waitedMs: Date.now() - started,
    timedOut: true,
  };
}

/* ---------- AI 专用标签 ----------
 *
 * 需求：人和 AI 同时用同一个浏览器，不能互相抢前台。
 * 做法：AI 自己占一个「专用标签」，所有命令默认都落在它身上，
 * 用户可以随便切到别的标签去看别的东西 —— AI 继续在后台那个标签里干活。
 *
 * 专用标签的挑选规则：
 *   1. 已经存在一个我们自己的专用标签（AGENT_TAB）→ 继续用它
 *   2. 否则从「非活动标签」里挑一个可注入的（http/https/file/about），
 *      避免动用户正看着的那一个
 *   3. 一个都没有 → 新开一个（这会新建标签，但只在真的没得用时）
 *
 * AGENT_TAB 只在本扩展后台页生命周期内有效；浏览器重启后重新挑。
 */
let AGENT_TAB = null;

const AGENT_TAB_KEY = 'bb.agentTab';

/* AGENT_TAB 落盘：后台页被系统挂起/回收后，内存里的 id 就丢了，
 * 于是「goto 建的那个专用标签」和「text 读的标签」就对不上了 ——
 * 这正是实测清单 #6 里「不传 tab 就读错页面」的根因。
 * 落盘后重启后台页也能接回同一个标签。 */
async function saveAgentTab(id) {
  AGENT_TAB = (id == null ? null : Number(id));
  try {
    if (AGENT_TAB == null) await browser.storage.local.remove(AGENT_TAB_KEY);
    else await browser.storage.local.set({ [AGENT_TAB_KEY]: AGENT_TAB });
  } catch (_) { /* 存不了就只在内存里用 */ }
}

async function restoreAgentTab() {
  try {
    const o = await browser.storage.local.get(AGENT_TAB_KEY);
    const v = o && o[AGENT_TAB_KEY];
    if (v == null) return null;
    const t = await browser.tabs.get(Number(v));
    if (t && t.id != null) { AGENT_TAB = t.id; return t; }
  } catch (_) { /* 标签没了就当没有 */ }
  return null;
}

/** 这个标签能不能注入（内部页/新标签页不行） */
function injectable(t) {
  if (!t) return false;
  if (t.discarded || t.status === 'unloaded') return false;
  return /^https?:|^file:|^about:/.test(t.url || '');
}

/** 找一个能注入的 http(s) 标签：优先 AI 专用标签，其次最近用过的，最后任意一个。
 *  浏览器的新标签页是 chrome://newtab/（或 chrome-extension://），
 *  扩展没法往里注入 —— 这时候不该直接报错，而该换一个能用的标签。 */
async function pickInjectableTab(preferId) {
  if (preferId != null) {
    try {
      const t = await browser.tabs.get(preferId);
      if (injectable(t)) return t;
    } catch (_) { /* 已经关了 */ }
  }
  let tabs = [];
  try { tabs = await browser.tabs.query({}); } catch (_) { tabs = []; }
  const usable = tabs.filter(injectable);
  if (usable.length) {
    /* 优先刚才那个 AI 专用标签 */
    if (AGENT_TAB != null) {
      const hit = usable.find((t) => t.id === AGENT_TAB);
      if (hit) return hit;
    }
    return usable[0];
  }
  return null;
}

/** 找一个 AI 能用的标签（不动用户正在看的那个） */
async function pickAgentTab() {
  /* 0) 后台页重启过：先从 storage 里接回上一个专用标签 */
  if (AGENT_TAB == null) await restoreAgentTab();
  /* 1) 上次用的那个还在、还能用，就继续用 */
  if (AGENT_TAB != null) {
    try {
      const t = await browser.tabs.get(AGENT_TAB);
      if (t && t.id != null) return t;
    } catch (_) { /* 已经关了 */ }
    AGENT_TAB = null;
  }

  /* 2) 从所有标签里挑一个「不是当前活动标签、且可注入」的 */
  let tabs = [];
  try { tabs = await browser.tabs.query({}); } catch (_) { tabs = []; }
  const activeIds = new Set();
  try {
    const at = await browser.tabs.query({ active: true });
    for (const t of at) activeIds.add(t.id);
  } catch (_) { /* ignore */ }

  const cands = tabs.filter((t) => injectable(t) && !activeIds.has(t.id));
  if (cands.length) {
    await saveAgentTab(cands[0].id);
    return cands[0];
  }

  /* 3) 只有当前活动标签能用（没有别的标签）→ 就用它，
   *    这时候无法避免抢前台，但至少不会再新建标签。 */
  if (tabs.length === 1 && injectable(tabs[0])) {
    await saveAgentTab(tabs[0].id);
    return tabs[0];
  }

  /* 4) 真没得用 → 新开一个专用标签 */
  try {
    const t = await browser.tabs.create({ url: 'about:blank', active: false });
    await saveAgentTab(t.id);
    return t;
  } catch (e) {
    throw new Error('没有可用的标签（也没有权限新建）：' + ((e && e.message) || e));
  }
}

/** 命令要落在哪个标签：显式指定 > AI 专用标签 > 活动标签 */
async function targetTab(tabId) {
  if (tabId) return tabById(tabId);
  try { return await pickAgentTab(); } catch (_) { return activeTab(); }
}

/** 在目标标签页执行函数，返回可结构化克隆的值 */
/* ---------- 被控制标签的可见标记 ----------
 * 光晕/胶囊那种页面内浮层会挡住内容，这里只做两件不打扰的事：
 *   1) 标题前面加 "◆ "（切换标签页时一眼认出这是 AI 在用的那个）
 *   2) favicon 换成一个橙点
 * 都只改 DOM，页面一刷新自动复原；需要提前复原就调 page.unmark。
 */
const MARK_PREFIX = '\u25c6 ';

/* 键盘 keyCode：不少老代码库只认这两个数字，不认 key。
 * 放在文件顶层，但 fPress 也会用到 —— 所以 fPress 里得自带一份。 */
const KEY_CODES = {
  Enter: 13, Escape: 27, Tab: 9, Backspace: 8, Delete: 46, Space: 32,
  ArrowUp: 38, ArrowDown: 40, ArrowLeft: 37, ArrowRight: 39,
  PageUp: 33, PageDown: 34, Home: 36, End: 35,
};
/* AI 标记图标：32x32 动画 GIF（蓝色短线环绕 + 呼吸白心）。
 * 用在标签栏的 favicon 位置 —— 浏览器真正的标签栏是 chrome:// 内部页，
 * 扩展改不了它的样式；但 favicon 是页面自己的图标，浏览器会把它画在标签上，
 * 动画 favicon 在标签栏里会跟着动。这才是「光效落在 1 号位（标签栏）」的唯一可行解法。
 * 页内的顶边光条/呼吸光环只是网页内容，位置在正文区，不在标签栏。 */
const MARK_ICON = 'data:image/gif;base64,R0lGODlhIAAgAIEAAAAAAABNa/7T/wAAACH/C05FVFNDQVBFMi4wAwEAAAAh+QQJCQAAACwAAAAAIAAgAAAIhgABCBxIsKDBgwgTKlzIsKHDhxAjSiwYoGKAiQQvDrSoEaPFjR8ncuy4MSPEkAkrYlSIciXFlhAFyDRIEiFHgjJzzjypEqfOnQ9b/tTJk+TQnBl7OjwKFABMhkdf1oQ6NKlSm1ORinzq0unVriAXck1p0upYsTcFnmU4MqzLtGDjyp1Ld2FAACH5BAkJAAAALAUABQAXABcAgQAAAABNa/7j/wAAAAhvAAEIHCgwgEGCCBMSNHhwYEOFCxk6lAhxIkKGDxdWtJiQ4kaFGD9C9DhQgEmQASqaXHlyYkaCLFdefCkwJsuIKRPalNkx486WM3OWtDmS5M6KQhHyjCiyKM2mJAs+ZRqUZlKkGaNixXm1KQCtAgMCACH5BAkJAAAALAUABQAXABcAgQAAAABNa/7y/wAAAAhwAAEIHEgQQICDAQoqHJiQIcKFCh8KRNgQokGKEQlW1HjQ4sSNHhdKDClyJEQBKDN+7DgQpcuUJUG+dAnR5MyXMQnepOkQpMCdMFeevFnQpE6iPRuyPCogJEaSOaGWdLpUo1WOT2tmNRpzaVWPWSEGBAAh+QQJCQAAACwFAAUAFwAXAIEAAAAATWv++/8AAAAIbwABCBwoMIBBgggTEjR4cGBDhQsZOpQIcSJChg8XVrSYkOJGhRg/QvQ4UIBJkAEqmlx5cmJGgixXXnwpMCbLiCkT2pTZMePOljNzlrQ5kuTOikIR8owosijNpiQLPmUalGZSpBmjYsV5tSkArQIDAgAh+QQJCQAAACwFAAUAFwAXAIEAAAAATWv+//8AAAAIcAABCBxIEECAgwEKKhyYkCHChQofCkTYEKJBihEJVtR40OLEjR4XSgwpciREASgzfuw4EKXLlCVBvnQJ0eTMlzEJ3qTpEKTAnTBXnrxZ0KROoj0bsjwqICRGkjmhlnS6VKNVjk9rZjUac2lVj1khBgQAIfkECQkAAAAsBQAFABcAFwCBAAAAAE1r/vv/AAAACG8AAQgcKDCAQYIIExI0eHBgQ4ULGTqUCHEiQoYPF1a0mJDiRoUYP0L0OFCASZABKppceXJiRoIsV158KTAmy4gpE9qU2THjzpYzc5a0OZLkzopCEfKMKLIozaYkCz5lGpRmUqQZo2LFebUpAK0CAwIAIfkECQkAAAAsBQAFABcAFwCBAAAAAE1r/vL/AAAACHAAAQgcSBBAgIMBCiocmJAhwoUKHwpE2BCiQYoRCVbUeNDixI0eF0oMKXIkRAEoM37sOBCly5QlQb50CdHkzJcxCd6k6RCkwJ0wV568WdCkTqI9G7I8KiAkRpI5oZZ0ulSjVY5Pa2Y1GnNpVY9ZIQYEACH5BAkJAAAALAUABQAXABcAgQAAAABNa/7j/wAAAAhvAAEIHCgwgEGCCBMSNHhwYEOFCxk6lAhxIkKGDxdWtJiQ4kaFGD9C9DhQgEmQASqaXHlyYkaCLFdefCkwJsuIKRPalNkx486WM3OWtDmS5M6KQhHyjCiyKM2mJAs+ZRqUZlKkGaNixXm1KQCtAgMCACH5BAkJAAAALAUABQAXABcAgQAAAABNa/7T/wAAAAhwAAEIHEgQQICDAQoqHJiQIcKFCh8KRNgQokGKEQlW1HjQ4sSNHhdKDClyJEQBKDN+7DgQpcuUJUG+dAnR5MyXMQnepOkQpMCdMFeevFnQpE6iPRuyPCogJEaSOaGWdLpUo1WOT2tmNRpzaVWPWSEGBAAh+QQJCQAAACwFAAUAFwAXAIEAAAAATWv+wv8AAAAIbwABCBwoMIBBgggTEjR4cGBDhQsZOpQIcSJChg8XVrSYkOJGhRg/QvQ4UIBJkAEqmlx5cmJGgixXXnwpMCbLiCkT2pTZMePOljNzlrQ5kuTOikIR8owosijNpiQLPmUalGZSpBmjYsV5tSkArQIDAgAh+QQJCQAAACwFAAUAFwAXAIEAAAAATWv+tP8AAAAIcAABCBxIEECAgwEKKhyYkCHChQofCkTYEKJBihEJVtR40OLEjR4XSgwpciREASgzfuw4EKXLlCVBvnQJ0eTMlzEJ3qTpEKTAnTBXnrxZ0KROoj0bsjwqICRGkjmhlnS6VKNVjk9rZjUac2lVj1khBgQAIfkECQkAAAAsBQAFABcAFwCBAAAAAE1r/qr/AAAACG8AAQgcKDCAQYIIExI0eHBgQ4ULGTqUCHEiQoYPF1a0mJDiRoUYP0L0OFCASZABKppceXJiRoIsV158KTAmy4gpE9qU2THjzpYzc5a0OZLkzopCEfKMKLIozaYkCz5lGpRmUqQZo2LFebUpAK0CAwIAIfkECQkAAAAsBQAFABcAFwCBAAAAAE1r/qf/AAAACHAAAQgcSBBAgIMBCiocmJAhwoUKHwpE2BCiQYoRCVbUeNDixI0eF0oMKXIkRAEoM37sOBCly5QlQb50CdHkzJcxCd6k6RCkwJ0wV568WdCkTqI9G7I8KiAkRpI5oZZ0ulSjVY5Pa2Y1GnNpVY9ZIQYEACH5BAkJAAAALAUABQAXABcAgQAAAABNa/6q/wAAAAhvAAEIHCgwgEGCCBMSNHhwYEOFCxk6lAhxIkKGDxdWtJiQ4kaFGD9C9DhQgEmQASqaXHlyYkaCLFdefCkwJsuIKRPalNkx486WM3OWtDmS5M6KQhHyjCiyKM2mJAs+ZRqUZlKkGaNixXm1KQCtAgMCACH5BAkJAAAALAUABQAXABcAgQAAAABNa/60/wAAAAhwAAEIHEgQQICDAQoqHJiQIcKFCh8KRNgQokGKEQlW1HjQ4sSNHhdKDClyJEQBKDN+7DgQpcuUJUG+dAnR5MyXMQnepOkQpMCdMFeevFnQpE6iPRuyPCogJEaSOaGWdLpUo1WOT2tmNRpzaVWPWSEGBAAh+QQJCQAAACwFAAUAFwAXAIEAAAAATWv+wv8AAAAIbwABCBwoMIBBgggTEjR4cGBDhQsZOpQIcSJChg8XVrSYkOJGhRg/QvQ4UIBJkAEqmlx5cmJGgixXXnwpMCbLiCkT2pTZMePOljNzlrQ5kuTOikIR8owosijNpiQLPmUalGZSpBmjYsV5tSkArQIDAgA7';

function fMark(a) {
  const ON = a.on !== false;
  const PREFIX = a.prefix || '\u25c6 ';
  const html = document.documentElement;
  const st = html.dataset;
  const findIcon = () => document.querySelector('link[rel~="icon"], link[rel="shortcut icon"]');

  if (ON) {
    if (st.bbTitle0 === undefined) st.bbTitle0 = document.title || '';
    if (!String(document.title || '').startsWith(PREFIX)) document.title = PREFIX + (st.bbTitle0 || document.title || '');
    if (st.bbIcon0 === undefined) {
      const l = findIcon();
      st.bbIcon0 = l ? l.href : '';
      if (l) l.href = a.icon;
      else {
        const n = document.createElement('link');
        n.rel = 'icon';
        n.href = a.icon;
        n.setAttribute('data-bb-mark', '1');
        (document.head || html).appendChild(n);
      }
    }
    if (!st.bbWatch) {
      st.bbWatch = '1';
      /* SPA 会不停改标题，用一个观察器把前缀挂回去（只观察 title 节点，代价很低） */
      const target = document.querySelector('title') || document.head;
      const mo = new MutationObserver(() => {
        if (html.dataset.bbMarkOn === '0') return;
        const cur = document.title || '';
        if (cur && !cur.startsWith(PREFIX)) {
          html.dataset.bbTitle0 = cur;
          document.title = PREFIX + cur;
        }
      });
      try { mo.observe(target, { childList: true, subtree: true, characterData: true }); } catch (_) {}
      window.__bbMarkObs = mo;
    }
    st.bbMarkOn = '1';
    return { marked: true, title: document.title };
  }

  st.bbMarkOn = '0';
  if (window.__bbMarkObs) { try { window.__bbMarkObs.disconnect(); } catch (_) {} window.__bbMarkObs = null; }
  /* 撤掉光效条 */
  const bar = document.querySelector('[data-bb-bar]');
  if (bar) { try { bar.remove(); } catch (_) {} }
  /* 撤掉呼吸光环 */
  const ring = document.querySelector('[data-bb-ring]');
  if (ring) { try { ring.remove(); } catch (_) {} }
  if (st.bbTitle0 !== undefined) {
    document.title = st.bbTitle0;
    delete st.bbTitle0;
  }
  /* 先摘掉自己塞的那个，再还页面原本的 icon */
  const mine = document.querySelector('link[data-bb-mark]');
  if (mine) { try { mine.remove(); } catch (_) {} }
  if (st.bbIcon0 !== undefined) {
    const l = findIcon();
    if (l && st.bbIcon0) l.href = st.bbIcon0;
    else if (l && !st.bbIcon0) { try { l.remove(); } catch (_) {} }
    delete st.bbIcon0;
  }
  delete st.bbWatch;
  return { marked: false, title: document.title };
}

/* ---------- 标记块外面那圈呼吸光环 ----------
 *
 * 想法：浏览器真正的标签栏是 chrome:// 内部界面，扩展改不了它的样式，
 * 所以「围着标签栏那一小块发光」只能在页面里画。我们把打标记的那个 ◆
 * 做成页面左上角的一个小徽标（跟标签上那个 ◆ 一一对应），
 * 外面套两圈反向旋转的虚线光环 —— 一圈快一圈慢 —— 再叠一层整体呼吸。
 *
 * 全部是 CSS 动画（transform / opacity），不吃 JS 主线程；
 * pointer-events:none，不挡任何内容；刷新页面自动复原。
 */
function fRing(a) {
  const ON = a.on !== false;
  const html = document.documentElement;
  const old = document.querySelector('[data-bb-ring]');

  if (!ON) {
    if (old) { try { old.remove(); } catch (_) {} }
    const st = document.querySelector('[data-bb-ring-style]');
    if (st) { try { st.remove(); } catch (_) {} }
    delete html.dataset.bbRingOn;
    return { ring: false };
  }

  if (!old) {
    /* 样式一次注入即可 */
    if (!document.querySelector('[data-bb-ring-style]')) {
      const style = document.createElement('style');
      style.setAttribute('data-bb-ring-style', '1');
      style.textContent = [
        '@keyframes bb-spin-cw{from{transform:rotate(0)}to{transform:rotate(360deg)}}',
        '@keyframes bb-spin-ccw{from{transform:rotate(0)}to{transform:rotate(-360deg)}}',
        '@keyframes bb-breathe{0%,100%{opacity:.55}50%{opacity:1}}',
        '@keyframes bb-core{0%,100%{transform:scale(1)}50%{transform:scale(1.12)}}',
        '[data-bb-ring]{position:fixed;left:10px;top:10px;width:46px;height:46px;z-index:2147483646;pointer-events:none}',
        '[data-bb-ring] .bb-core{position:absolute;left:50%;top:50%;width:18px;height:18px;margin:-9px 0 0 -9px;border-radius:50%;background:#4D6BFE;color:#fff;font-size:12px;line-height:18px;text-align:center;animation:bb-core 1.8s ease-in-out infinite}',
        '[data-bb-ring] .bb-orbit{position:absolute;left:50%;top:50%;margin:-23px 0 0 -23px;width:46px;height:46px;border-radius:50%;border:2px dashed rgba(77,107,254,.9)}',
        '[data-bb-ring] .bb-orbit.fast{border-color:rgba(77,107,254,.95);animation:bb-spin-cw 1.6s linear infinite}',
        '[data-bb-ring] .bb-orbit.slow{border-color:rgba(77,107,254,.45);border-style:dotted;animation:bb-spin-ccw 4.2s linear infinite}',
        '[data-bb-ring].breathe{animation:bb-breathe 2.4s ease-in-out infinite}',
        '@media (prefers-reduced-motion:reduce){[data-bb-ring] *{animation:none!important}}',
      ].join('');
      (document.head || html).appendChild(style);
    }

    /* 徽标本体：内圈是 ◆（跟标签上的标记同一个符号），外面两圈虚线光环 */
    const wrap = document.createElement('div');
    wrap.setAttribute('data-bb-ring', '1');
    wrap.className = 'breathe';

    const fast = document.createElement('div');
    fast.className = 'bb-orbit fast';
    const slow = document.createElement('div');
    slow.className = 'bb-orbit slow';
    const core = document.createElement('div');
    core.className = 'bb-core';
    core.textContent = '\u25c6';

    wrap.appendChild(fast);
    wrap.appendChild(slow);
    wrap.appendChild(core);
    (document.body || html).appendChild(wrap);
  } else {
    old.classList.add('breathe');
  }
  html.dataset.bbRingOn = '1';
  return { ring: true };
}

/* ---------- AI 正在用的那个标签：顶边一条流动光效 ----------
 *
 * 画在页面视口的最上沿一条 3px 的窄条里：一段亮蓝沿着一排短划往前跑，
 * 像标签栏下沿在发光。桌面端它紧贴标签栏，手机端贴在内容区顶部。
 * 纯 CSS 动画（transform 偏移），不占 JS 主线程；只改 DOM，刷新即复原。
 * 「亮蓝」用的是 DeepSeek 主题色 #4D6BFE。
 */
function fBar(a) {
  const html = document.documentElement;
  const ON = a.on !== false;
  const old = document.querySelector('[data-bb-bar]');

  if (!ON) {
    if (old) { try { old.remove(); } catch (_) {} }
    delete html.dataset.bbBarOn;
    return { bar: false };
  }

  if (old) {
    old.remove();
  } else {
    const wrap = document.createElement('div');
    wrap.setAttribute('data-bb-bar', '1');
    /* 贴顶、左右通栏、高 3px；pointer-events:none 保证完全不挡内容 */
    wrap.style.cssText = [
      'position:fixed', 'top:0', 'left:0', 'right:0', 'height:3px',
      'z-index:2147483646', 'pointer-events:none', 'overflow:hidden',
      'background:repeating-linear-gradient(90deg,rgba(77,107,254,.16) 0 10px,rgba(77,107,254,0) 10px 22px)',
    ].join(';');

    /* 跑动的亮段：比容器宽，靠 transform 平移形成流动 */
    const run = document.createElement('div');
    run.style.cssText = [
      'position:absolute', 'top:0', 'left:0', 'height:3px', 'width:38%',
      'background:linear-gradient(90deg,rgba(77,107,254,0),#4D6BFE 55%,rgba(77,107,254,0))',
      'animation:bb-flow 1.15s linear infinite',
    ].join(';');

    const style = document.createElement('style');
    style.setAttribute('data-bb-bar-style', '1');
    style.textContent = '@keyframes bb-flow{from{transform:translateX(-120%)}to{transform:translateX(320%)}}' +
      '@media (prefers-reduced-motion:reduce){[data-bb-bar] div{animation:none!important}}';

    wrap.appendChild(run);
    (document.head || html).appendChild(style);
    (document.body || html).appendChild(wrap);
  }
  html.dataset.bbBarOn = '1';
  return { bar: true };
}

/** 已标记过的标签（只在当前后台页生命周期内有效）。 */
/** 截当前可视区。返回元数据（不塞像素），需要图像再要 base64。 */
async function captureShot(a) {
  const t = await targetTab(a.tabId);
  /* captureVisibleTab 只能拍「当前窗口的活动标签」，所以先把目标标签切到前台，
   * 拍完再切回用户原来在看的那一个 —— 尽量不让截图打断人。 */
  let restore = null;
  try {
    const at = await browser.tabs.query({ active: true, currentWindow: true });
    if (at && at[0] && at[0].id !== t.id) restore = at[0].id;
  } catch (_) { /* ignore */ }
  if (a.tabId) await browser.tabs.update(t.id, { active: true });
  const dataUrl = await browser.tabs.captureVisibleTab(t.windowId, { format: a.format || 'png', quality: a.quality || 90 });
  if (restore != null) { try { await browser.tabs.update(restore, { active: true }); } catch (_) {} }
  const b64 = String(dataUrl).split(',')[1] || '';
  return {
    tabId: t.id, url: t.url, title: t.title,
    mime: a.format === 'jpeg' ? 'image/jpeg' : 'image/png',
    bytes: Math.round(b64.length * 0.75),
    base64: (a.data === true || a.raw === true) ? b64 : undefined,
  };
}

const MARKED = new Set();

/* AI 专用标签的 favicon 用动画（蓝短线环绕 + 呼吸白心）：
 * 浏览器会把页面自己的 favicon 画在标签栏那个标签上，动画 favicon 就会跟着动 ——
 * 这就是「光效落在 1 号位（标签栏）」能做到的唯一解法。
 * 别的标签（用户自己的）用静态小圆点，只是告诉「这个页面被碰过」。 */
const MARK_ICON_STATIC = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAyElEQVR42u1XSxbCMAgMcz+9iB5HL6L3s67c+DDAAI2LsmzSGf6BMRaLRH84XV7b7Px5h7QoYBGzikg1cVQRdJJ7MNBJ7sFCN7mFiT3IZ9jCkD9uel6dr1s4MRG14he5dWaWoWV9FNzyxscLGItFWOu/LfTc0bwAJuYasPbNE7ZwCGZWeasgpUC1HAosb0Rgkk4jYsrw6ITUa2h5wuP21GtY3Yhkz4FEG1KRneuzEzIqlovMeI6qDYfdDVC5ZjEY/7+adS+ny+UNV0R2Mjdax4AAAAAASUVORK5CYII=';

async function markTab(tabId, on, animated) {
  const icon = animated === true ? MARK_ICON : MARK_ICON_STATIC;
  try {
    if (browser.tabs && browser.tabs.executeScript) {
      await browser.tabs.executeScript(tabId, {
        code: `(${fMark.toString()})(${JSON.stringify({ on: on !== false, prefix: MARK_PREFIX, icon: icon })})`,
        runAt: 'document_idle',
      });
    } else {
      await browser.scripting.executeScript({
        target: { tabId },
        func: fMark,
        args: [{ on: on !== false, prefix: MARK_PREFIX, icon: icon }],
      });
    }
    if (on === false) MARKED.delete(tabId); else MARKED.add(tabId);
    return true;
  } catch (_) { return false; }
}

/* 顶边流动光效条：只给「AI 正在用的那个」标签挂上 */
async function barTab(tabId, on) {
  try {
    if (browser.tabs && browser.tabs.executeScript) {
      await browser.tabs.executeScript(tabId, {
        code: `(${fBar.toString()})(${JSON.stringify({ on: on !== false })})`,
        runAt: 'document_idle',
      });
    } else {
      await browser.scripting.executeScript({
        target: { tabId },
        func: fBar,
        args: [{ on: on !== false }],
      });
    }
    return true;
  } catch (_) { return false; }
}

/* 光效只挂在 AI 专用标签上：换标签时把旧的撤掉、新的挂上 */
let BAR_TAB = null;

async function moveBar(toId) {
  if (BAR_TAB != null && BAR_TAB !== toId) {
    await barTab(BAR_TAB, false);
    BAR_TAB = null;
  }
  if (toId == null) return null;
  if (BAR_TAB === toId) return BAR_TAB;
  const okb = await barTab(toId, true);
  BAR_TAB = okb ? toId : null;
  return BAR_TAB;
}

/* 呼吸光环：围着页面里那个 ◆ 标记块转，同样只挂 AI 专用标签 */
let RING_TAB = null;

async function ringTab(tabId, on) {
  try {
    if (browser.tabs && browser.tabs.executeScript) {
      await browser.tabs.executeScript(tabId, {
        code: `(${fRing.toString()})(${JSON.stringify({ on: on !== false })})`,
        runAt: 'document_idle',
      });
    } else {
      await browser.scripting.executeScript({
        target: { tabId },
        func: fRing,
        args: [{ on: on !== false }],
      });
    }
    return true;
  } catch (_) { return false; }
}

async function moveRing(toId) {
  if (RING_TAB != null && RING_TAB !== toId) {
    await ringTab(RING_TAB, false);
    RING_TAB = null;
  }
  if (toId == null) return null;
  if (RING_TAB === toId) return RING_TAB;
  const okr = await ringTab(toId, true);
  RING_TAB = okr ? toId : null;
  return RING_TAB;
}

/* 解析出「能往里注入」的标签，并保证它没被系统丢弃。
 * 指定 tabId > AI 专用标签 > 活动标签；
 * 浏览器内部页（chrome://newtab/ 之类）注入不了，就换一个能用的标签。 */
async function prepareTab(tabId) {
  let tab = await targetTab(tabId);
  if (!tab || !/^https?:|^file:|^about:/.test(tab.url || '')) {
    const alt = await pickInjectableTab(tabId);
    if (alt) tab = alt;
  }
  if (!tab || !tab.id) throw new Error('no tab available');
  const url = tab.url || '';
  if (!/^https?:|^file:|^about:/.test(url)) {
    throw new Error('没有可注入的页面（当前标签是 ' + url.slice(0, 40) + '，扩展无法注入浏览器内部页；请先打开一个 http(s) 页面）');
  }

  /* Android 的 Chromium 会把后台标签「丢弃」(discarded)，此时注入必然报
   * "Cannot access contents of the page"。先把它重新载活再注入。 */
  if (tab.discarded || tab.status === 'unloaded') {
    try { await browser.tabs.reload(tab.id) } catch (_) { /* 忽略：下面用轮询兜底 */ }
    for (let i = 0; i < 25; i++) {
      await new Promise((r) => setTimeout(r, 300));
      try {
        const t = await browser.tabs.get(tab.id);
        if (t && t.status === 'complete') break;
      } catch (_) { break; }
    }
  }
  return tab;
}

/* 页内顶边光条 / 呼吸光环：默认关。
 *
 * 用户要的效果在「1 号位」= 浏览器标签栏那个标签上，不是网页正文区。
 * 标签栏是 chrome:// 内部页，扩展改不了它的样式；能做到的是给那个标签
 * 换一个动画 favicon —— 浏览器会把它画在标签上。
 * 页内光条/光环属于「2/3 号位」（网页内容里），只在显式 bar/ring 时才画。 */
let BAR_ON = false;
let RING_ON = false;

/* 注入后的统一收尾：打标题标记（AI 专用标签用动画 favicon） */
function afterInject(tabId) {
  const isAgent = tabId === AGENT_TAB;
  if (!MARKED.has(tabId)) void markTab(tabId, true, isAgent);
  else if (isAgent) void markTab(tabId, true, true);
  if (BAR_ON) void moveBar(tabId);
  if (RING_ON) void moveRing(tabId);
}

async function inPage(fn, args, tabId) {
  const tab = await prepareTab(tabId);
  // MV2: tabs.executeScript；MV3: scripting.executeScript
  if (browser.tabs && browser.tabs.executeScript) {
    const res = await browser.tabs.executeScript(tab.id, {
      code: `(${fn.toString()})(${JSON.stringify(args || {})})`,
      runAt: 'document_idle',
    });
    afterInject(tab.id);
    /* 空结果 = 页面里那次执行没产出任何东西（脚本抛错、或被页面 CSP 拦了）。
     * 绝不能当成成功 —— 「点了但没反应」和「点了」必须分得开，
     * 否则调用方根本没法判断到底成没成。 */
    if (!res || !res.length || res[0] === undefined || res[0] === null) {
      throw new Error('页面脚本没有返回结果（执行被中断或页面拦截）');
    }
    return res[0];
  }
  /* MV3：只能传函数（func），没有 code 参数，所以「执行一段字符串」走不到这里 ——
   * 那件事由 eval-host.js 负责（各平台一份，见 inPageCode）。
   * 这里跑的都是我们自己写死的函数，ISOLATED 世界足够。 */
  const res = await browser.scripting.executeScript({
    target: { tabId: tab.id }, func: fn, args: [args || {}],
  });
  afterInject(tab.id);
  if (!res || !res.length || !res[0] || res[0].result === undefined || res[0].result === null) {
    throw new Error('页面脚本没有返回结果（执行被中断或页面拦截）');
  }
  return res[0].result;
}

/* 在页面里执行一段字符串（page.eval 用的）。
 *
 * 「怎么求值」由各平台的 eval-host.js 决定，接口一致：
 *   __bbEvalHost(tabId, code, timeoutMs) -> { result } | { error }
 *   - Firefox（MV2）：用 tabs.executeScript({code})，让浏览器自己去求值；
 *     扩展源码里因此不出现 eval，AMO 的 addons-linter 不会报 DANGEROUS_EVAL。
 *   - Chromium（MV3）：scripting.executeScript 没有 code 参数，
 *     只能在 MAIN 世界里求值，那份实现只存在于 Chromium 包（cr/eval-host.js）。
 *
 * 拆成两个文件而不是改 background.js，是为了守住 build.mjs 那条守卫：
 * 两边 background.js 必须逐字节相同。 */
async function inPageCode(code, tabId, timeoutMs) {
  const tab = await prepareTab(tabId);
  const host = self.__bbEvalHost;
  if (typeof host !== 'function') {
    throw new Error('这个浏览器上 page.eval 不可用（缺少 eval-host.js）');
  }
  const out = await host(tab.id, code, timeoutMs);
  afterInject(tab.id);
  return out || { error: 'page.eval 没有返回结果' };
}

/* ---------- 出站脱敏（与 redact.js 同规则，内联以免加载顺序问题） ---------- */

const RD_RULES = [
  { n: 'idcard', re: /\b(\d{6})(\d{8})(\d{3}[\dXx])\b/g, f: (m, a, b, c) => `${a}********${c}` },
  { n: 'bankcard', re: /\b(\d{12,15})(\d{4})\b/g, f: (m, a, b) => `${'*'.repeat(a.length)}${b}` },
  { n: 'phone', re: /\b(1[3-9]\d)\d{4}(\d{4})\b/g, f: (m, a, b) => `${a}****${b}` },
  { n: 'email', re: /\b([A-Za-z0-9._%+-])[A-Za-z0-9._%+-]*(@[A-Za-z0-9.-]+\.[A-Za-z]{2,})\b/g, f: (m, a, b) => `${a}***${b}` },
  { n: 'kv', re: /\b(password|passwd|pwd|secret|token|apikey|api_key|api-key|authorization|auth|session|sessionid|csrf|xsrf|otp|pin|cvv)\b(\s*[:=]\s*)(["']?)([^\s"',;}\]]{3,})/gi,
    f: (m, k, sep, q, v) => `${k}${sep}${q}${'*'.repeat(Math.min(v.length, 12))}` },
  { n: 'jwt', re: /\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\b/g, f: () => 'eyJ***.***.***' },
  { n: 'privkey', re: /-----BEGIN [A-Z ]*PRIVATE KEY-----[\s\S]{20,}?-----END [A-Z ]*PRIVATE KEY-----/g, f: () => '[REDACTED PRIVATE KEY]' },
];

const RD_SKIP = new Set(['ping', 'tabs.list', 'tab.get']);

function cmdSafe(c) { return String(c || ''); }

function rdStr(str, only) {
  if (typeof str !== 'string' || !str) return str;
  let out = str;
  for (const r of RD_RULES) {
    if (only && !only.includes(r.n)) continue;
    out = out.replace(r.re, r.f);
  }
  return out;
}

function rdDeep(v, only, d) {
  d = d || 0;
  if (d > 12) return '[too deep]';
  if (typeof v === 'string') return rdStr(v, only);
  if (v === null || typeof v !== 'object') return v;
  if (Array.isArray(v)) return v.map((x) => rdDeep(x, only, d + 1));
  const o = {};
  for (const k of Object.keys(v)) o[k] = rdDeep(v[k], only, d + 1);
  return o;
}

/** 对一条命令的结果做脱敏。args.redact === false 时整条跳过。 */
function BB_redact(cmd, data, args) {
  if (args && args.redact === false) return data;
  if (RD_SKIP.has(cmd)) return data;
  const only = args && Array.isArray(args.onlyRules) ? args.onlyRules : null;
  return rdDeep(data, only, 0);
}

/** 值指纹：非可逆短哈希，用来判断「是不是换了」而不是「是什么」 */
function fingerprint(s) {
  const str = String(s == null ? '' : s);
  let h = 0x811c9dc5;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 0x01000193) >>> 0;
  }
  return h.toString(16).padStart(8, '0');
}

/** cookie 值专用掩码 */
function maskCookie(v) {
  const s = String(v == null ? '' : v);
  if (s.length <= 4) return '*'.repeat(s.length || 1);
  if (s.length <= 12) return s[0] + '*'.repeat(s.length - 2) + s.slice(-1);
  return s.slice(0, 2) + '*'.repeat(Math.min(s.length - 4, 24)) + s.slice(-2) + `[len ${s.length}]`;
}

function trunc(s, n) {
  s = String(s == null ? '' : s);
  return s.length > n ? s.slice(0, n) + `\n…[truncated ${s.length - n} chars]` : s;
}

/* ---------- 页面内执行的函数（会被序列化注入） ---------- */

function fInfo() {
  const d = document;
  return {
    url: location.href,
    title: d.title,
    readyState: d.readyState,
    lang: d.documentElement.lang || null,
    charset: d.characterSet,
    viewport: { w: innerWidth, h: innerHeight, dpr: devicePixelRatio },
    scroll: { x: scrollX, y: scrollY, maxY: Math.max(0, d.documentElement.scrollHeight - innerHeight) },
    doc: { w: d.documentElement.scrollWidth, h: d.documentElement.scrollHeight },
    selection: String(getSelection() || '').slice(0, 2000),
    forms: d.forms.length,
    links: d.links.length,
    images: d.images.length,
  };
}

function fText(a) {
  const max = (a && a.max) || 20000;
  const sel = (a && a.selector) || 'body';
  const root = document.querySelector(sel);
  if (!root) return { error: 'selector not found: ' + sel };
  let t = root.innerText || root.textContent || '';
  t = t.replace(/[ \t\u00a0]+/g, ' ').replace(/\n{3,}/g, '\n\n').trim();
  return { selector: sel, length: t.length, text: t.slice(0, max) };
}

function fHtml(a) {
  const max = (a && a.max) || 60000;
  const sel = (a && a.selector) || 'html';
  const root = document.querySelector(sel);
  if (!root) return { error: 'selector not found: ' + sel };
  const h = root.outerHTML;
  return { selector: sel, length: h.length, html: h.slice(0, max) };
}

function fLinks(a) {
  const max = (a && a.max) || 300;
  const only = a && a.filter ? String(a.filter).toLowerCase() : null;
  const out = [];
  for (const el of document.querySelectorAll('a[href]')) {
    const text = (el.innerText || el.getAttribute('aria-label') || '').replace(/\s+/g, ' ').trim();
    const href = el.href;
    if (only) {
      const hay = (text + ' ' + href).toLowerCase();
      if (!hay.includes(only)) continue;
    }
    out.push({ text: text.slice(0, 160), href });
    if (out.length >= max) break;
  }
  return { count: out.length, links: out };
}

function fQuery(a) {
  /* 选择器解析：CSS / `aria-ref=e3` / `e3` / `[data-bb-ref="e3"]`。
   * 必须定义在函数体内 —— 这个函数会被单独注入页面，
   * 外部作用域里的同名函数在页面里并不存在。 */
  const bbSel = (s) => {
    const raw = String(s == null ? '' : s).trim();
    const m = /^(?:aria-ref=)?(e[0-9]+)$/.exec(raw) || /^\[(?:data-bb-ref|ref)=["']?(e[0-9]+)["']?\]$/.exec(raw);
    return m ? '[data-bb-ref="' + m[1] + '"]' : raw;
  };
  const sel = bbSel(a.selector);
  const max = a.max || 50;
  const nodes = Array.from(document.querySelectorAll(sel)).slice(0, max);
  return {
    selector: sel,
    total: document.querySelectorAll(sel).length,
    items: nodes.map((n) => ({
      tag: n.tagName,
      text: (n.innerText || n.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 300),
      html: n.outerHTML.slice(0, 1200),
      attrs: Array.from(n.attributes || []).reduce((o, at) => (o[at.name] = at.value, o), {}),
      rect: (() => { const r = n.getBoundingClientRect(); return { x: Math.round(r.x), y: Math.round(r.y), w: Math.round(r.width), h: Math.round(r.height) }; })(),
    })),
  };
}

/* page.eval 的求值细节在 eval-host.js 里（各平台一份，接口一致）：
 * Firefox 用 tabs.executeScript({code}) 让浏览器自己去执行，Chromium 用页面主世界。
 * 这一侧只负责「把它跑起来、把结果拿回来」，不碰求值本身。 */


/** 选择器统一入口：支持 CSS、`aria-ref=e3`、`e3`、`[data-bb-ref="e3"]`。
 * 一切能定位元素的命令都先过这里，快照给的引用在哪个命令里都能用。 */
function bbSel(s) {
  const raw = String(s == null ? '' : s).trim();
  const m = /^(?:aria-ref=)?(e[0-9]+)$/.exec(raw) || /^\[(?:data-bb-ref|ref)=["']?(e[0-9]+)["']?\]$/.exec(raw);
  return m ? '[data-bb-ref="' + m[1] + '"]' : raw;
}

function fClick(a) {
  /* 选择器解析：CSS / `aria-ref=e3` / `e3` / `[data-bb-ref="e3"]`。
   * 必须定义在函数体内 —— 这个函数会被单独注入页面，
   * 外部作用域里的同名函数在页面里并不存在。 */
  const bbSel = (s) => {
    const raw = String(s == null ? '' : s).trim();
    const m = /^(?:aria-ref=)?(e[0-9]+)$/.exec(raw) || /^\[(?:data-bb-ref|ref)=["']?(e[0-9]+)["']?\]$/.exec(raw);
    return m ? '[data-bb-ref="' + m[1] + '"]' : raw;
  };
  const sel = bbSel(a.selector);
  const hits = document.querySelectorAll(sel).length;
  const el = document.querySelector(sel);
  if (!el) return { ok: false, error: 'not found: ' + a.selector, hit: 0 };
  el.scrollIntoView({ block: 'center' });
  if (a.href && el.tagName === 'A' && !a.keepHref) {
    location.href = a.href;
    return { ok: true, hit: hits, tag: el.tagName, navigated: a.href };
  }
  const before = location.href;
  let threw = null;
  try {
    el.click();
  } catch (e) {
    threw = (e && e.message) || String(e);
  }
  return {
    ok: !threw,
    hit: hits,
    tag: el.tagName,
    text: (el.innerText || '').slice(0, 80),
    href: el.href || null,
    beforeUrl: before,
    afterUrl: location.href,
    navigated: before !== location.href,
    /* click() 是同步的，导航要等下一个任务；这里只能报告「已触发」，
     * 真正到没到新页面由调用方再看一次 page.info。 */
    dispatched: !threw,
    error: threw || undefined,
  };
}

function fFill(a) {
  /* 选择器解析：CSS / `aria-ref=e3` / `e3` / `[data-bb-ref="e3"]`。
   * 必须定义在函数体内 —— 这个函数会被单独注入页面，
   * 外部作用域里的同名函数在页面里并不存在。 */
  const bbSel = (s) => {
    const raw = String(s == null ? '' : s).trim();
    const m = /^(?:aria-ref=)?(e[0-9]+)$/.exec(raw) || /^\[(?:data-bb-ref|ref)=["']?(e[0-9]+)["']?\]$/.exec(raw);
    return m ? '[data-bb-ref="' + m[1] + '"]' : raw;
  };
  const sel = bbSel(a.selector);
  const hits = document.querySelectorAll(sel).length;
  const el = document.querySelector(sel);
  if (!el) return { ok: false, error: 'not found: ' + a.selector, hit: 0 };
  el.focus();
  const v = a.value == null ? '' : String(a.value);
  const before = 'value' in el ? String(el.value == null ? '' : el.value) : null;
  let threw = null;
  try {
    if (el.isContentEditable) {
      el.textContent = v;
    } else {
      const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      const desc = Object.getOwnPropertyDescriptor(proto, 'value');
      /* 受控组件（React/Vue）会劫持 value setter，必须走原型上的原生 setter，
       * 直接 el.value = x 会被忽略。取不到 setter 就退回普通赋值。 */
      if (desc && desc.set) desc.set.call(el, v);
      else el.value = v;
    }
    for (const ev of ['input', 'change', 'keyup']) {
      el.dispatchEvent(new Event(ev, { bubbles: true }));
    }
    if (a.submit && el.form) el.form.requestSubmit ? el.form.requestSubmit() : el.form.submit();
  } catch (e) {
    threw = (e && e.message) || String(e);
  }
  const after = 'value' in el ? String(el.value == null ? '' : el.value) : null;
  return {
    ok: !threw && after === v,
    hit: hits,
    tag: el.tagName,
    before,
    after,
    /* value property 和 value attribute 是两回事：受控组件可能只更新前者 */
    valueAttribute: el.getAttribute ? el.getAttribute('value') : null,
    changed: before !== after,
    submitted: !!(a.submit && el.form),
    error: threw || (after !== v ? '值没有真正写进去（可能被页面重置了）' : undefined),
  };
}

function fScroll(a) {
  if (a.to === 'bottom') scrollTo({ top: document.documentElement.scrollHeight, behavior: 'smooth' });
  else if (a.to === 'top') scrollTo({ top: 0, behavior: 'smooth' });
  else if (typeof a.y === 'number') scrollTo({ top: a.y, behavior: 'smooth' });
  else scrollBy({ top: a.by == null ? innerHeight * 0.8 : a.by, behavior: 'smooth' });
  return { ok: true, y: Math.round(scrollY) };
}

function fWait(a) {
  /* 选择器解析：CSS / `aria-ref=e3` / `e3` / `[data-bb-ref="e3"]`。
   * 必须定义在函数体内 —— 这个函数会被单独注入页面，
   * 外部作用域里的同名函数在页面里并不存在。 */
  const bbSel = (s) => {
    const raw = String(s == null ? '' : s).trim();
    const m = /^(?:aria-ref=)?(e[0-9]+)$/.exec(raw) || /^\[(?:data-bb-ref|ref)=["']?(e[0-9]+)["']?\]$/.exec(raw);
    return m ? '[data-bb-ref="' + m[1] + '"]' : raw;
  };
  const sel = bbSel(a.selector);
  const ms = Math.min(a.ms || 8000, 20000);
  return new Promise((resolve) => {
    const t0 = Date.now();
    const hit = () => document.querySelector(sel);
    if (hit()) return resolve({ ok: true, waitedMs: 0 });
    const iv = setInterval(() => {
      if (hit()) { clearInterval(iv); resolve({ ok: true, waitedMs: Date.now() - t0 }); }
      else if (Date.now() - t0 > ms) { clearInterval(iv); resolve({ ok: false, error: 'timeout', waitedMs: Date.now() - t0 }); }
    }, 200);
  });
}

/* ---------- 交互补全：press / select / scrollTo / waitFor ---------- */

/** 在目标元素上按一次键。手机没有物理回车键，搜索框、登录框多半要 Enter 才提交，
 * 所以 Enter 额外兜一层 form.requestSubmit()（很多站点监听的是 submit 而不是 keydown）。 */
function fPress(a) {
  /* 选择器解析：CSS / `aria-ref=e3` / `e3` / `[data-bb-ref="e3"]`。
   * 必须定义在函数体内 —— 这个函数会被单独注入页面，
   * 外部作用域里的同名函数在页面里并不存在。 */
  const bbSel = (s) => {
    const raw = String(s == null ? '' : s).trim();
    const m = /^(?:aria-ref=)?(e[0-9]+)$/.exec(raw) || /^\[(?:data-bb-ref|ref)=["']?(e[0-9]+)["']?\]$/.exec(raw);
    return m ? '[data-bb-ref="' + m[1] + '"]' : raw;
  };
  /* 老代码库只认 keyCode/charCode，不认 key —— 自带一份映射。
   * 必须定义在函数体内：注入页面时外部作用域不存在。 */
  const KEY_CODES = {
    Enter: 13, Escape: 27, Tab: 9, Backspace: 8, Delete: 46, Space: 32,
    ArrowUp: 38, ArrowDown: 40, ArrowLeft: 37, ArrowRight: 39,
    PageUp: 33, PageDown: 34, Home: 36, End: 35,
  };
  const sel = a.selector ? bbSel(a.selector) : '';
  const el = (sel && document.querySelector(sel)) || document.activeElement || document.body;
  if (!el) return { ok: false, error: 'no target element', hit: 0 };
  const keys = Array.isArray(a.keys) ? a.keys : String(a.keys || a.key || 'Enter').split(/[+\s]+/).filter(Boolean);
  const key = keys[keys.length - 1] || 'Enter';
  const mods = { alt: keys.includes('Alt'), ctrl: keys.includes('Control') || keys.includes('Ctrl'),
    shift: keys.includes('Shift'), meta: keys.includes('Meta') };
  try { el.focus({ preventScroll: false }) } catch (_) { /* 元素不可聚焦就按在 document 上 */ }

  const mk = (type, code) => {
    /* keyCode / charCode 也要给：不少老代码库只认这两个数字，
     * 只给 key 的话按下去等于没按。 */
    const keyCode = KEY_CODES[key] || key.toUpperCase().charCodeAt(0);
    const ev = new KeyboardEvent(type, {
      key, code, bubbles: true, cancelable: true,
      keyCode, charCode: type === 'keypress' ? keyCode : 0,
      altKey: mods.alt, ctrlKey: mods.ctrl, shiftKey: mods.shift, metaKey: mods.meta,
    });
    el.dispatchEvent(ev);
    return ev.defaultPrevented;
  };
  const codeMap = { Enter: 'Enter', Escape: 'Escape', Tab: 'Tab', Backspace: 'Backspace', Delete: 'Delete',
    ArrowUp: 'ArrowUp', ArrowDown: 'ArrowDown', ArrowLeft: 'ArrowLeft', ArrowRight: 'ArrowRight', ' ': 'Space' };
  const code = codeMap[key] || ('Key' + key.toUpperCase());
  const preventedDown = mk('keydown', code);
  mk('keypress', code);
  mk('keyup', code);

  let submitted = false;
  if (key === 'Enter' && el.form && el.form.requestSubmit) {
    /* 用户明确要「提交」时才补这一手；不替页面做别的决定 */
    setTimeout(() => { try { el.form.requestSubmit() } catch (_) {} }, 0);
    submitted = true;
  }
  return {
    ok: true,
    hit: sel ? document.querySelectorAll(sel).length : 1,
    key, code, tag: el.tagName,
    focused: document.activeElement === el,
    /* 被页面 preventDefault 吃掉了 —— 那这次按键对页面就是没发生 */
    prevented: preventedDown,
    submitted,
    value: (el.value == null ? '' : String(el.value)).slice(0, 120),
  };
}

/** 下拉框选值。fill 对 <select> 无效，必须设 value 再派发 change。 */
function fSelect(a) {
  /* 选择器解析：CSS / `aria-ref=e3` / `e3` / `[data-bb-ref="e3"]`。
   * 必须定义在函数体内 —— 这个函数会被单独注入页面，
   * 外部作用域里的同名函数在页面里并不存在。 */
  const bbSel = (s) => {
    const raw = String(s == null ? '' : s).trim();
    const m = /^(?:aria-ref=)?(e[0-9]+)$/.exec(raw) || /^\[(?:data-bb-ref|ref)=["']?(e[0-9]+)["']?\]$/.exec(raw);
    return m ? '[data-bb-ref="' + m[1] + '"]' : raw;
  };
  const el = document.querySelector(bbSel(a.selector));
  if (!el) return { error: 'not found: ' + a.selector };
  if (!/^SELECT$/i.test(el.tagName)) return { error: 'not a <select>: ' + el.tagName };
  const opts = Array.from(el.options || []);
  let idx = -1;
  if (a.index != null) idx = Number(a.index);
  else if (a.label != null) idx = opts.findIndex((o) => (o.textContent || '').trim() === String(a.label).trim());
  else if (a.value != null) idx = opts.findIndex((o) => o.value === String(a.value));
  if (idx < 0 || !opts[idx]) {
    return { error: 'option not found', options: opts.slice(0, 20).map((o) => ({ value: o.value, label: (o.textContent || '').trim() })) };
  }
  el.value = opts[idx].value;
  for (const ev of ['input', 'change']) el.dispatchEvent(new Event(ev, { bubbles: true }));
  return { ok: true, value: el.value, label: (opts[idx].textContent || '').trim(), index: idx };
}

/** 滚到某个元素（不是「滚一屏」）。长页面上找东西全靠它。 */
function fScrollTo(a) {
  /* 选择器解析：CSS / `aria-ref=e3` / `e3` / `[data-bb-ref="e3"]`。
   * 必须定义在函数体内 —— 这个函数会被单独注入页面，
   * 外部作用域里的同名函数在页面里并不存在。 */
  const bbSel = (s) => {
    const raw = String(s == null ? '' : s).trim();
    const m = /^(?:aria-ref=)?(e[0-9]+)$/.exec(raw) || /^\[(?:data-bb-ref|ref)=["']?(e[0-9]+)["']?\]$/.exec(raw);
    return m ? '[data-bb-ref="' + m[1] + '"]' : raw;
  };
  if (a.selector) {
    const el = document.querySelector(bbSel(a.selector));
    if (!el) return { error: 'not found: ' + a.selector };
    el.scrollIntoView({ block: a.block || 'center', inline: 'nearest', behavior: a.smooth === false ? 'auto' : 'smooth' });
    const r = el.getBoundingClientRect();
    return { ok: true, y: Math.round(scrollY), rect: { x: Math.round(r.x), y: Math.round(r.y), w: Math.round(r.width), h: Math.round(r.height) },
      visible: r.bottom > 0 && r.top < innerHeight };
  }
  const y = a.y === 'bottom' ? document.documentElement.scrollHeight : Number(a.y || 0);
  scrollTo({ top: y, behavior: a.smooth === false ? 'auto' : 'smooth' });
  return { ok: true, y: Math.round(scrollY) };
}

/** 等到某个条件成立再返回。比盲等 sleep 稳：站点慢的时候不会读到旧页面，
 * 快的时候不浪费时间。kind: selector（默认）| text | gone（元素消失）| url。 */
function fWaitFor(a) {
  /* 选择器解析：CSS / `aria-ref=e3` / `e3` / `[data-bb-ref="e3"]`。
   * 必须定义在函数体内 —— 这个函数会被单独注入页面，
   * 外部作用域里的同名函数在页面里并不存在。 */
  const bbSel = (s) => {
    const raw = String(s == null ? '' : s).trim();
    const m = /^(?:aria-ref=)?(e[0-9]+)$/.exec(raw) || /^\[(?:data-bb-ref|ref)=["']?(e[0-9]+)["']?\]$/.exec(raw);
    return m ? '[data-bb-ref="' + m[1] + '"]' : raw;
  };
  const kind = a.kind || 'selector';
  const ms = Math.min(Number(a.ms) || 15000, 25000);
  const sel = a.selector ? bbSel(a.selector) : '';
  const text = a.text == null ? '' : String(a.text);
  const t0 = Date.now();
  const hit = () => {
    if (kind === 'selector') {
      const el = sel ? document.querySelector(sel) : null;
      if (!el) return false;
      if (a.visible === true) {
        const r = el.getBoundingClientRect();
        const cs = getComputedStyle(el);
        return r.width > 0 && r.height > 0 && cs.visibility !== 'hidden' && cs.display !== 'none';
      }
      return true;
    }
    if (kind === 'text') return (document.body ? document.body.innerText : '').includes(text);
    if (kind === 'gone') return !sel || !document.querySelector(sel);
    if (kind === 'url') return String(a.url || '') ? location.href.includes(String(a.url)) : document.readyState === 'complete';
    return true;
  };
  return new Promise((resolve) => {
    if (hit()) return resolve({ ok: true, kind, waitedMs: 0, url: location.href });
    const iv = setInterval(() => {
      if (hit()) {
        clearInterval(iv);
        resolve({ ok: true, kind, waitedMs: Date.now() - t0, url: location.href });
      } else if (Date.now() - t0 > ms) {
        clearInterval(iv);
        resolve({ ok: false, kind, error: 'timeout（' + ms + 'ms）', waitedMs: Date.now() - t0, url: location.href });
      }
    }, 250);
  });
}

/* ---------- 弹窗：不 freeze，改为「记录 + 按策略应答」 ----------
 *
 * alert/confirm/prompt 是同步阻塞的：一旦弹出，页面里所有脚本停住，
 * 我们的注入也跟着停，直到有人手点。手机上没有手点的人（用户在看别的 app），
 * 所以这里换成非阻塞版本：记录内容、按策略立刻给答案（默认 confirm=true, prompt=''），
 * 页面继续跑，我们事后能看见「它问过什么」。策略可以改。 */
function fDialog(a) {
  const op = a.op || 'status';
  const W = window;
  if (!W.__bbDlg) {
    const D = { log: [], policy: { confirm: true, prompt: '' }, installedAt: Date.now(), native: {} };
    W.__bbDlg = D;
    D.native = { alert: W.alert, confirm: W.confirm, prompt: W.prompt };
    W.alert = function (msg) {
      D.log.push({ type: 'alert', message: String(msg == null ? '' : msg), at: Date.now() });
      return undefined;
    };
    W.confirm = function (msg) {
      const answer = D.policy.confirm !== false;
      D.log.push({ type: 'confirm', message: String(msg == null ? '' : msg), answer, at: Date.now() });
      return answer;
    };
    W.prompt = function (msg, def) {
      const answer = D.policy.prompt != null ? String(D.policy.prompt) : String(def == null ? '' : def);
      D.log.push({ type: 'prompt', message: String(msg == null ? '' : msg), answer, at: Date.now() });
      return answer;
    };
    D.log.push({ type: 'install', at: Date.now() });
  }
  const D = W.__bbDlg;
  if (op === 'clear') { D.log = []; return { ok: true, cleared: true }; }
  if (op === 'policy') {
    if (a.policy && typeof a.policy === 'object') {
      if ('confirm' in a.policy) D.policy.confirm = a.policy.confirm !== false;
      if ('prompt' in a.policy) D.policy.prompt = a.policy.prompt == null ? null : String(a.policy.prompt);
    }
    return { ok: true, policy: D.policy };
  }
  if (op === 'restore') {
    try { if (D.native.alert) W.alert = D.native.alert; if (D.native.confirm) W.confirm = D.native.confirm; if (D.native.prompt) W.prompt = D.native.prompt; } catch (_) {}
    delete W.__bbDlg;
    return { ok: true, restored: true };
  }
  D.log = D.log.slice(-40);
  return { ok: true, installed: true, policy: D.policy, count: D.log.length, log: D.log.slice(-10) };
}

/* ---------- 让用户接管（对应手机端的 handoff） ----------
 *
 * 登录、验证码、支付这类事只能人来做。这里在页面上放一条横幅，说清要做什么，
 * 用户弄完点「继续」，agent 才接着走；不点就等到超时，并明确告诉 agent「人没回来」。 */
function fRequestHelp(a) {
  const id = 'bb-help-' + Date.now().toString(36);
  const text = String(a.message || '需要你在这页完成一步（登录 / 验证码 / 确认）');
  const wait = a.wait !== false;
  const ms = Math.min(Number(a.ms) || 120000, 300000);
  const old = document.getElementById('bb-help');
  if (old) old.remove();

  return new Promise((resolve) => {
    const box = document.createElement('div');
    box.id = 'bb-help';
    box.setAttribute('data-bb-help', id);
    box.style.cssText = [
      'position:fixed', 'left:12px', 'right:12px', 'bottom:16px', 'z-index:2147483647',
      'background:#4D6BFE', 'color:#fff', 'border-radius:14px', 'padding:14px 16px',
      'font:14px/1.5 -apple-system,system-ui,"Segoe UI",Roboto,sans-serif',
      'box-shadow:0 8px 28px rgba(0,0,0,.28)', 'display:flex', 'flex-direction:column', 'gap:10px',
    ].join(';');
    const msg = document.createElement('div');
    msg.textContent = text;
    const row = document.createElement('div');
    row.style.cssText = 'display:flex;gap:8px;justify-content:flex-end';
    const mkBtn = (label, bg, color, onClick) => {
      const b = document.createElement('button');
      b.type = 'button';
      b.textContent = label;
      b.style.cssText = 'border:0;border-radius:10px;padding:8px 14px;font-size:14px;font-weight:600;' +
        'background:' + bg + ';color:' + color + ';cursor:pointer';
      b.addEventListener('click', onClick);
      return b;
    };
    let done = false;
    const finish = (how) => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      try { box.remove() } catch (_) {}
      /* shown 也算成功：横幅确实放出来了，只是没等人 */
      resolve({ ok: how === 'done' || how === 'shown', how, waitedMs: Date.now() - t0 });
    };
    const t0 = Date.now();
    const timer = setTimeout(() => finish('timeout'), ms);
    row.appendChild(mkBtn('我还没好', 'rgba(255,255,255,.18)', '#fff', () => finish('timeout')));
    row.appendChild(mkBtn('继续', '#fff', '#4D6BFE', () => finish('done')));
    box.appendChild(msg);
    box.appendChild(row);
    (document.body || document.documentElement).appendChild(box);

    if (!wait) { finish('shown'); return; }
  });
}

/* ---------- 一次拿齐：状态 + 快照（省往返） ---------- */

/* fSnapshot —— 精简的可交互元素快照（a11y 风格 + 稳定引用）。
 *
 * 为什么不直接给整页 HTML 或截图：
 *  - 截图像素进上下文太贵（一屏 100KB+），手机上还只有 400×400 的视口；
 *  - outerHTML 噪声大，模型要自己找「哪个能点」，一次就吃掉几千 token。
 * 这里只挑人/模型真正会操作的元素，给稳定引用 data-bb-ref="eN"，
 * 之后 page.click / page.fill / page.wait 都能直接写 aria-ref=eN。
 * 引用每刷新一次重新编号，页面结构变了就重新 snapshot。 */
function fSnapshot(a) {
  const max = Math.min((a && a.max) || 120, 300);
  const withRect = !!(a && a.rect);
  const root = document.body || document.documentElement;
  if (!root) return { error: 'no body' };

  const SEL = [
    'a[href]', 'button', 'input', 'textarea', 'select', 'summary',
    '[role=button]', '[role=link]', '[role=tab]', '[role=checkbox]', '[role=radio]',
    '[role=menuitem]', '[role=combobox]', '[role=switch]', '[role=option]',
    '[contenteditable=""]', '[contenteditable=true]', '[onclick]',
  ].join(',');

  const visible = (el) => {
    if (el.hidden) return false;
    const cs = getComputedStyle(el);
    if (cs.display === 'none' || cs.visibility === 'hidden' || Number(cs.opacity) === 0) return false;
    const r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0;
  };

  const nameOf = (el) => {
    const t = el.tagName;
    if (t === 'INPUT' || t === 'TEXTAREA' || t === 'SELECT') {
      const lab = el.labels && el.labels[0];
      return String(
        el.getAttribute('aria-label') || (lab && lab.innerText) || el.getAttribute('placeholder') ||
        el.getAttribute('title') || el.value || el.name || ''
      ).replace(/\s+/g, ' ').trim().slice(0, 120);
    }
    return String(
      el.getAttribute('aria-label') || el.getAttribute('title') ||
      el.innerText || el.textContent || ''
    ).replace(/\s+/g, ' ').trim().slice(0, 120);
  };

  const roleOf = (el) => {
    const r = el.getAttribute('role');
    if (r) return r;
    const t = el.tagName;
    if (t === 'A') return 'link';
    if (t === 'BUTTON') return 'button';
    if (t === 'INPUT') {
      const ty = (el.type || 'text').toLowerCase();
      if (ty === 'checkbox') return 'checkbox';
      if (ty === 'radio') return 'radio';
      if (ty === 'submit' || ty === 'button') return 'button';
      if (ty === 'search') return 'searchbox';
      return 'textbox';
    }
    if (t === 'TEXTAREA') return 'textbox';
    if (t === 'SELECT') return 'combobox';
    if (t === 'SUMMARY') return 'button';
    return 'generic';
  };

  /* 清掉上一轮的编号，避免和这轮的引用混在一起 */
  for (const old of document.querySelectorAll('[data-bb-ref]')) old.removeAttribute('data-bb-ref');

  const els = Array.from(root.querySelectorAll(SEL));
  const out = [];
  let n = 0;
  for (const el of els) {
    if (n >= max) break;
    if (!visible(el)) continue;
    const ref = 'e' + (++n);
    try { el.setAttribute('data-bb-ref', ref) } catch (_) { continue }
    const item = { ref, role: roleOf(el), name: nameOf(el) };
    const t = el.tagName;
    if (t === 'A') item.href = String(el.getAttribute('href') || '').slice(0, 300);
    if (t === 'INPUT' || t === 'TEXTAREA' || t === 'SELECT') {
      item.tag = t.toLowerCase();
      item.type = (el.type || '').toLowerCase() || undefined;
      if (el.type === 'checkbox' || el.type === 'radio') item.checked = !!el.checked;
      else if (el.value) item.value = String(el.value).slice(0, 80);
      if (el.disabled) item.disabled = true;
      if (el.readOnly) item.readonly = true;
    }
    if (el.getAttribute('aria-expanded') != null) item.expanded = el.getAttribute('aria-expanded') === 'true';
    if (withRect) {
      const r = el.getBoundingClientRect();
      item.rect = { x: Math.round(r.x), y: Math.round(r.y), w: Math.round(r.width), h: Math.round(r.height) };
    }
    out.push(item);
  }

  return {
    url: location.href,
    title: document.title,
    count: out.length,
    truncated: els.length > out.length,
    hint: '引用写法：selector 里直接写 aria-ref=eN 或 [data-bb-ref=eN]。页面结构变了就重新 snapshot。',
    items: out,
  };
}

function fMeta() {
  const out = { meta: {}, jsonld: [], og: {} };
  for (const m of document.querySelectorAll('meta')) {
    const k = m.getAttribute('property') || m.getAttribute('name');
    const v = m.getAttribute('content');
    if (!k || !v) continue;
    out.meta[k] = v.slice(0, 400);
    if (k.startsWith('og:')) out.og[k] = v.slice(0, 400);
  }
  for (const s of document.querySelectorAll('script[type="application/ld+json"]')) {
    try { out.jsonld.push(JSON.parse(s.textContent)); } catch (_) {}
  }
  out.canonical = (document.querySelector('link[rel=canonical]') || {}).href || null;
  return out;
}

function fEmails(a) {
  const max = (a && a.max) || 100;
  const txt = document.body ? (document.body.innerText || '') : '';
  const html = document.documentElement.outerHTML || '';
  const re = /[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}/g;
  const uniq = new Set((txt.match(re) || []).concat((html.match(re) || [])));
  return { count: uniq.size, emails: Array.from(uniq).slice(0, max) };
}

function fPhones(a) {
  const max = (a && a.max) || 100;
  const txt = document.body ? (document.body.innerText || '') : '';
  const re = /(?:\+?86[-\s]?)?1[3-9]\d{9}|(?:\+?\d{1,3}[-\s]?)?\(?\d{2,4}\)?[-\s]?\d{3,4}[-\s]?\d{4}/g;
  const uniq = new Set((txt.match(re) || []).map((s) => s.replace(/[\s\-()]/g, '')));
  const valid = Array.from(uniq).filter((s) => s.length >= 7 && s.length <= 15);
  return { count: valid.length, phones: valid.slice(0, max) };
}

/* ---------- 命令表 ---------- */

const CMDS = {
  /* 跳转前先探活。
   * 手机上直接 location.assign 到一个不可达的域名（被墙 / DNS 挂掉），
   * 导航请求会一直挂着不返回，后台页等不到 load，Android 就把整个标签回收 ——
   * 表现为「跳一下页面直接没了，只剩扩展状态页」。
   * 所以先 fetch 探一次：连 TCP/TLS 都拿不到就别跳，原地保留当前页。
   * probe 失败也不一定真不可达（有些站禁跨域 HEAD），所以失败后再做一次
   * no-cors GET 兜底；两次都失败才判定不可达。 */
  async 'nav.probe'(a) {
    const url = String((a && a.url) || '');
    if (!/^https?:\/\//.test(url)) return { ok: false, error: 'only http(s)' };
    const ms = Math.min(Number(a && a.timeout) || 6000, 15000);
    const tryFetch = async (opts) => {
      const ctl = new AbortController();
      const t = setTimeout(() => ctl.abort(), ms);
      try {
        const r = await fetch(url, Object.assign({ signal: ctl.signal, cache: 'no-store' }, opts));
        return { ok: true, status: r.status, type: r.type };
      } catch (e) {
        return { ok: false, error: (e && e.name) + ': ' + (e && e.message) };
      } finally { clearTimeout(t); }
    };
    const head = await tryFetch({ method: 'HEAD' });
    if (head.ok) return { ok: true, url, via: 'head', status: head.status, type: head.type };
    const get = await tryFetch({ method: 'GET', mode: 'no-cors' });
    if (get.ok) return { ok: true, url, via: 'get', status: get.status, type: get.type };
    return { ok: false, url, error: get.error || head.error, via: 'none' };
  },

  /* 探活通过才跳。不可达时标签原样保留，不冒被回收的风险。
   *
   * waitUntil：导航之后必须有个同步点，否则「goto 返回」和「页面加载完成」
   * 之间有缝，调用方紧接着读页面会读到旧页或空壳。
   *   load            —— 等 load 事件（默认，最常用）
   *   domcontentloaded —— DOM 好了就返回（快）
   *   none            —— 不等，发起就返回（navigation:'pending'）
   */
  async 'nav.goto'(a) {
    const url = String((a && a.url) || '');
    if (!/^https?:\/\//.test(url)) throw new Error('only http(s)');
    if (a.probe !== false) {
      const p = await CMDS['nav.probe']({ url, timeout: a.probeTimeout });
      if (!p.ok) {
        return { ok: false, skipped: true, url, error: '目标不可达，已取消跳转（页面保留）：' + p.error };
      }
    }
    if (a.newTab === true) {
      const t = await browser.tabs.create({ url, active: true });
      const w = await waitTabLoaded(t.id, a.waitUntil, a.timeoutMs);
      return { ok: true, url, tabId: t.id, opened: true, ...w };
    }
    /* 落在 AI 专用标签上，不动用户正在看的那一个 */
    const tab = await targetTab(a.tabId);
    await browser.tabs.update(tab.id, { url });
    await saveAgentTab(tab.id);
    const w = await waitTabLoaded(tab.id, a.waitUntil, a.timeoutMs);
    /* 换到动画 favicon：标签栏那个标签上的动效靠它 */
    void markTab(tab.id, true, true);
    if (BAR_ON) void moveBar(tab.id);
    if (RING_ON) void moveRing(tab.id);
    return { ok: true, url, tabId: tab.id, ...w };
  },

  /* 诊断：扩展侧最近发生过什么。后台页挂起后靠这个复盘断点。 */
  async 'diag.log'(a) {
    const buf = await diagLoad();
    const n = Math.min(Number(a && a.limit) || 80, DIAG_MAX);
    return { total: buf.length, lines: buf.slice(-n) };
  },
  async 'diag.clear'() {
    diagBuf = [];
    try { await browser.storage.local.remove(DIAG_KEY); } catch (_) {}
    return { ok: true };
  },

  async ping() {
    const h = await bbHealth().catch(() => null);
    return {
      pong: true,
      sid: SID,
      agent: navigator.userAgent,
      platform: navigator.platform,
      bridge: h,
      uaData: navigator.userAgentData ? { mobile: navigator.userAgentData.mobile, brands: navigator.userAgentData.brands } : null,
    };
  },

  async 'tabs.list'(a) {
    const ts = await browser.tabs.query({});
    return {
      count: ts.length,
      agentTabId: AGENT_TAB,
      tabs: ts.map((t) => ({
        id: t.id, index: t.index, active: !!t.active, pinned: !!t.pinned,
        title: t.title, url: t.url, status: t.status,
        favIconUrl: t.favIconUrl || null,
        controlled: MARKED.has(t.id),
        /* 这个标签是不是 AI 正在用的（顶边有流动光效的那条） */
        agent: t.id === AGENT_TAB,
        glowing: t.id === BAR_TAB,
        /* 有没有围着 ◆ 标记的呼吸光环 */
        ringed: t.id === RING_TAB,
      })),
    };
  },

  async 'tab.get'() {
    const t = await activeTab();
    return { id: t.id, title: t.title, url: t.url, status: t.status, incognito: !!t.incognito };
  },

  /* AI 专用标签：显式查/显式换。
   * pick  —— 现在挑一个能用的（优先非活动标签），返回它
   * use   —— 之后所有命令都落在这个标签上
   * release —— 放弃专用标签，下次重新挑（光效也会撤掉） */
  async 'tab.agent'(a) {
    const op = String((a && a.op) || 'pick');
    if (op === 'release') {
      const old = AGENT_TAB;
      await saveAgentTab(null);
      if (old != null) await barTab(old, false);
      if (BAR_TAB === old) BAR_TAB = null;
      if (old != null) await ringTab(old, false);
      if (RING_TAB === old) RING_TAB = null;
      return { ok: true, released: old };
    }
    if (op === 'use') {
      const t = await targetTab(a.tabId);
      await saveAgentTab(t.id);
      void moveBar(t.id);
      void moveRing(t.id);
      return { ok: true, tabId: t.id, url: t.url, title: t.title };
    }
    const t = await pickAgentTab();
    await saveAgentTab(t.id);
    void moveBar(t.id);
    void moveRing(t.id);
    return { ok: true, tabId: t.id, url: t.url, title: t.title, active: !!t.active };
  },

  /* 页内顶边光条：默认关（用户要的是标签栏 1 号位）。
   * 显式 on 才画在网页顶部 —— 那是「3 号位」，不是标签栏。 */
  async 'page.bar'(a) {
    const on = !(a && a.on === false);
    if (!on) {
      BAR_ON = false;
      if (BAR_TAB != null) await barTab(BAR_TAB, false);
      BAR_TAB = null;
      return { ok: true, bar: false };
    }
    BAR_ON = true;
    const tab = await targetTab(a && a.tabId);
    const okb = await barTab(tab.id, true);
    BAR_TAB = okb ? tab.id : null;
    return { ok: true, bar: !!okb, tabId: tab.id, note: '页内光条在网页顶部（3 号位）；标签栏（1 号位）请看 favicon 动效' };
  },

  /* 呼吸光环：围着页面里那个 ◆ 标记块转（两圈虚线，一快一慢）。
   * 同样默认关 —— 它画在网页左上角，是正文区的浮层，不是标签栏。 */
  async 'page.ring'(a) {
    const on = !(a && a.on === false);
    if (!on) {
      RING_ON = false;
      if (RING_TAB != null) await ringTab(RING_TAB, false);
      RING_TAB = null;
      return { ok: true, ring: false };
    }
    RING_ON = true;
    const tab = await targetTab(a && a.tabId);
    const okr = await ringTab(tab.id, true);
    RING_TAB = okr ? tab.id : null;
    return { ok: true, ring: !!okr, tabId: tab.id, note: '页内光环在网页左上角（3 号位）；标签栏（1 号位）请看 favicon 动效' };
  },

  async 'tab.open'(a) {
    if (!a.url) throw new Error('url required');
    const t = await browser.tabs.create({ url: a.url, active: a.active !== false });
    if (a.waitMs) await new Promise((r) => setTimeout(r, Math.min(a.waitMs, 20000)));
    return { id: t.id, url: t.url, title: t.title };
  },

  async 'tab.close'(a) {
    const id = a.tabId || (await targetTab(null)).id;
    await browser.tabs.remove(id);
    if (AGENT_TAB === id) await saveAgentTab(null);
    if (BAR_TAB === id) BAR_TAB = null;
    return { closed: id };
  },

  async 'tab.activate'(a) {
    const id = a.tabId || (await targetTab(null)).id;
    await browser.tabs.update(id, { active: true });
    return { active: id };
  },

  async 'tab.reload'(a) {
    const id = a.tabId || (await targetTab(null)).id;
    await browser.tabs.reload(id, { bypassCache: !!a.hard });
    return { reloaded: id };
  },

  /* page.info 额外带上实际作用的 tabId：
   * 调用方不传 tab 时，命令可能落在 AI 专用标签上（不是当前活动标签），
   * 返回里必须说清楚「我读的是哪个标签」，否则下一轮就分不清了。 */
  async 'page.info'(a) {
    const tab = await targetTab(a && a.tabId);
    const info = await inPage(fInfo, {}, tab.id);
    return Object.assign({}, info, { tabId: tab.id, agent: tab.id === AGENT_TAB, active: !!tab.active });
  },
  async 'page.text'(a) { return inPage(fText, a || {}, a && a.tabId); },
  async 'page.html'(a) { return inPage(fHtml, a || {}, a && a.tabId); },
  async 'page.links'(a) { return inPage(fLinks, a || {}, a && a.tabId); },
  async 'page.query'(a) { if (!a.selector) throw new Error('selector required'); return inPage(fQuery, a, a.tabId); },
  async 'page.meta'(a) { return inPage(fMeta, {}, a && a.tabId); },
  async 'page.mark'(a) {
    const tab = await targetTab(a && a.tabId);
    const animated = tab.id === AGENT_TAB;
    const okm = await markTab(tab.id, true, animated);
    return { ok: okm, tabId: tab.id, marked: okm, animated, note: animated ? '标签栏 favicon 动画已开' : '普通标签用静态标记' };
  },
  async 'page.unmark'(a) {
    const ids = a.tabId ? [Number(a.tabId)] : Array.from(MARKED);
    const done = await Promise.all(ids.map((id) => markTab(id, false)));
    return { ok: true, tabs: ids.length, cleared: done.filter(Boolean).length };
  },
  async 'page.press'(a) { return inPage(fPress, a, a.tabId); },
  async 'page.select'(a) { return inPage(fSelect, a, a.tabId); },
  async 'page.scrollTo'(a) { return inPage(fScrollTo, a, a.tabId); },
  async 'page.waitFor'(a) { return inPage(fWaitFor, a, a.tabId); },
  async 'page.dialog'(a) { return inPage(fDialog, a, a.tabId); },
  async 'page.help'(a) { return inPage(fRequestHelp, a, a.tabId); },

  /* 一次拿齐状态 + 快照：手机上每多一次往返就多一份「后台页又被挂起」的风险 */
  async 'page.observe'(a) {
    const info = await inPage(fInfo, {}, a.tabId);
    const snap = await inPage(fSnapshot, { max: a.max, rect: a.rect }, a.tabId);
    const out = { info, snapshot: snap };
    if (a.shot) {
      try { out.screenshot = await captureShot(a); } catch (e) { out.shotError = String((e && e.message) || e); }
    }
    return out;
  },

  /* 前进/后退：优先用 tabs.goBack（不依赖页面里的 history，pdf 之类也能退） */
  async 'nav.back'(a) {
    const tab = await targetTab(a && a.tabId);
    if (typeof browser.tabs.goBack === 'function') { await browser.tabs.goBack(tab.id); return { ok: true, via: 'tabs.goBack' }; }
    await inPage(function () { history.back(); return { ok: true, via: 'history.back' }; }, {}, tab.id);
    return { ok: true, via: 'history.back' };
  },
  async 'nav.forward'(a) {
    const tab = await targetTab(a && a.tabId);
    if (typeof browser.tabs.goForward === 'function') { await browser.tabs.goForward(tab.id); return { ok: true, via: 'tabs.goForward' }; }
    await inPage(function () { history.forward(); return { ok: true, via: 'history.forward' }; }, {}, tab.id);
    return { ok: true, via: 'history.forward' };
  },

  async 'page.eval'(a) {
    if (!a.code) throw new Error('code required');
    try {
      return await inPageCode(a.code, a.tabId, a.timeout);
    } catch (e) {
      const msg = String((e && e.message) || e);
      if (/Content Security Policy|unsafe-eval/i.test(msg)) {
        throw new Error('这个站点的 CSP 禁止 eval（Chromium 限制）：' + msg.slice(0, 160));
      }
      throw e;
    }
  },
  async 'page.snapshot'(a) { return inPage(fSnapshot, a || {}, a && a.tabId); },
  async 'page.click'(a) { if (!a.selector) throw new Error('selector required'); return inPage(fClick, a, a.tabId); },
  async 'page.fill'(a) { if (!a.selector) throw new Error('selector required'); return inPage(fFill, a, a.tabId); },
  async 'page.scroll'(a) { return inPage(fScroll, a || {}, a && a.tabId); },
  async 'page.wait'(a) { if (!a.selector) throw new Error('selector required'); return inPage(fWait, a, a.tabId); },
  async 'extract.emails'(a) { return inPage(fEmails, a || {}, a && a.tabId); },
  async 'extract.phones'(a) { return inPage(fPhones, a || {}, a && a.tabId); },

  /* net.fetch —— 带浏览器自己的 cookie 去取一个 URL。
   *
   * 为什么要有这条：用户要的是「cookie 值能用来取数据，但值不能进上下文」。
   * 浏览器自己去发这个请求（fetch 带 credentials:'include'），
   * cookie 由浏览器附上，扩展从头到尾没碰过值 —— 值压根没进过 JS 作用域。
   * 回包只有状态码/类型/长度/正文，正文超阈值由桥接落盘。
   * 危险点：这不是「读页面」，是「以这个站点的身份发请求」，
   * 所以桥接那边按 call 级（每次都问）处理。 */
  async 'net.fetch'(a) {
    const url = String((a && a.url) || '');
    if (!/^https?:\/\//.test(url)) throw new Error('only http(s)');
    const tab = await targetTab(a && a.tabId);
    const method = String((a && a.method) || 'GET').toUpperCase();
    const body = a && a.body != null ? String(a.body) : null;
    const ctl = new AbortController();
    const t = setTimeout(() => ctl.abort(), Math.min(Number(a && a.timeout) || 30000, 60000));
    try {
      /* 在页面里发：同源时浏览器会自然带上该站点的 cookie */
      const res = await inPage(function (arg) {
        const ctl = new AbortController();
        const timer = setTimeout(() => ctl.abort(), arg.timeout || 30000);
        return fetch(arg.url, {
          method: arg.method,
          credentials: 'include',
          headers: arg.headers || {},
          body: arg.body,
          signal: ctl.signal,
        }).then(async (r) => {
          clearTimeout(timer);
          const buf = await r.arrayBuffer();
          let bin = '';
          const bytes = new Uint8Array(buf);
          for (let i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
          const ct = r.headers.get('content-type') || '';
          const isText = /^text\/|json|javascript|xml/i.test(ct);
          return {
            ok: r.ok,
            status: r.status,
            statusText: r.statusText,
            url: r.url,
            contentType: ct,
            bytes: bytes.length,
            body: isText ? btoa(unescape(encodeURIComponent(bin))) : '',
            binary: !isText,
          };
        }).catch((e) => ({ ok: false, error: String((e && e.message) || e) }));
      }, {
        url,
        method,
        body,
        headers: (a && a.headers) || {},
        timeout: Math.min(Number(a && a.timeout) || 30000, 60000),
      }, tab.id);
      if (res && res.error) return { ok: false, url, error: res.error };
      if (!res || res.binary) {
        return {
          ok: res && res.ok, status: res && res.status, url: (res && res.url) || url,
          contentType: res && res.contentType, bytes: res && res.bytes,
          binary: true, note: '二进制内容不进上下文',
        };
      }
      let text = '';
      try { text = decodeURIComponent(escape(atob(res.body || ''))); } catch (_) { text = ''; }
      return {
        ok: res.ok, status: res.status, statusText: res.statusText,
        url: res.url, contentType: res.contentType, bytes: res.bytes, text,
        usedBrowserCookies: true,
        note: 'cookie 由浏览器附带，值没有进入扩展也没有进入上下文',
      };
    } finally { clearTimeout(t); }
  },

  /* cookies.get —— 只给元数据，永远不给值。
   * 值一旦进入模型上下文就等于把会话交出去了，所以这里连掩码值都不返回，
   * 只给长度和指纹，够判断「有哪些 cookie、是不是 httpOnly、多大」。
   * 真要用 cookie 取数据，走 cookies.jar（只落盘）+ 桥接代取，值不出桥接进程。 */
  async 'cookies.get'(a) {
    const url = a.url || (await targetTab(null)).url;
    const q = { url };
    if (a.name) q.name = a.name;
    const cs = await browser.cookies.getAll(q);
    return {
      url,
      count: cs.length,
      valueMode: 'metadata-only',
      note: '值不外传；需要带 cookie 取页面请用 cookies.jar + fetch',
      cookies: cs.map((c) => {
        const v = String(c.value == null ? '' : c.value);
        return {
          name: c.name,
          length: v.length,
          fp: fingerprint(v),
          domain: c.domain, path: c.path, secure: !!c.secure, httpOnly: !!c.httpOnly,
          sameSite: c.sameSite, session: !c.expirationDate,
          expirationDate: c.expirationDate || null,
        };
      }),
    };
  },

  /* cookies.jar —— 内部命令：把全值交给桥接落盘，返回值经桥接处理后只剩路径与哈希。
   * 工具层对这条命令做了硬拒绝，模型拿不到它。 */
  async 'cookies.jar'(a) {
    const url = a.url || (await targetTab(null)).url;
    const q = { url };
    if (a.name) q.name = a.name;
    const cs = await browser.cookies.getAll(q);
    return {
      url,
      count: cs.length,
      // 只在「扩展 → 桥接」这一段出现，桥接立刻落盘并丢弃
      pairs: cs.map((c) => ({ name: c.name, value: String(c.value == null ? '' : c.value), domain: c.domain, path: c.path })),
    };
  },

  async screenshot(a) {
    /* 截图默认只给尺寸，不把整屏像素塞进上下文；要图像数据得显式 data:true */
    const shot = await captureShot(a);
    if (!shot.base64) shot.note = '需要图像数据请加 args:{data:true}';
    return shot;
  },

  async 'history.search'(a) {
    if (!browser.history) throw new Error('history API unavailable');
    const items = await browser.history.search({ text: a.q || '', maxResults: Math.min(a.max || 30, 200), startTime: 0 });
    return { count: items.length, items: items.map((h) => ({ title: h.title, url: h.url, lastVisitTime: h.lastVisitTime, visitCount: h.visitCount })) };
  },

  async 'bookmarks.search'(a) {
    if (!browser.bookmarks) throw new Error('bookmarks API unavailable');
    const items = a.q ? await browser.bookmarks.search(a.q) : await browser.bookmarks.getRecent(Math.min(a.max || 30, 100));
    return { count: items.length, items: items.filter((b) => b.url).map((b) => ({ id: b.id, title: b.title, url: b.url })) };
  },
};

/* ---------- 主循环 ---------- */

async function handle(job) {
  const fn = CMDS[job.cmd];
  if (!fn) {
    await bbResult(job.id, false, { message: 'unknown cmd: ' + job.cmd + ' (可用: ' + Object.keys(CMDS).join(', ') + ')' });
    return;
  }
  try {
    const raw = await fn(job.args || {});
    const args = job.args || {};
    const wantRaw = args.raw === true;
    const data = wantRaw ? raw : BB_redact(cmdSafe(job.cmd), raw, args);
    await bbResult(job.id, true, data);
    note('ok', job.cmd, wantRaw ? '(raw)' : '(masked)');
  } catch (e) {
    await bbResult(job.id, false, { message: (e && e.message) || String(e) });
    note('err', job.cmd, e && e.message);
  }
}

async function loop() {
  if (running) return;
  if (!TOKEN) await loadToken();
  if (!TOKEN) {
    // 未配对：先试一次自动配对；不行就等用户在设置页输入配对码
    const ok = await autoPair();
    if (!ok) { note('not paired yet'); return; }
  }
  running = true;
  let backoff = 1000;
  let fails = 0;
  while (running) {
    try {
      const job = await bbPoll();
      backoff = 1000;
      fails = 0;
      if (job) await handle(job);
    } catch (e) {
      if (e && e.auth) {
        // 令牌彻底失效：回到未配对，下一轮会重新走自动配对/配对码
        running = false;
        TOKEN = null;
        note('会话失效，停止轮询');
        return;
      }
      // 桥接没起来 / 开关关着：静默退避。失败越久退得越狠，
      // 最长 60 秒一次，免得桥接长期关着还在后台勤快空转。
      fails += 1
      const cap = fails > 8 ? 60000 : 15000
      await new Promise((r) => setTimeout(r, Math.min(backoff, cap)));
      backoff = Math.min(backoff * 2, cap);
    }
  }
}

/* 保活：Android 上后台页可能被回收，用 alarm 定期拉起 */
if (browser.alarms) {
  browser.alarms.create('bb-keepalive', { periodInMinutes: 1 });
  browser.alarms.onAlarm.addListener((al) => {
    if (al.name === 'bb-keepalive') loop();
  });
}

browser.runtime.onInstalled.addListener(() => {
  note('installed');
  loop();
  // 首次安装/更新后把设置页拉起来：安卓 Firefox 没有工具栏图标，不主动开就没人知道该配对
  loadToken().then((tok) => {
    if (!tok) { setBadge('!', '#C0504D'); try { browser.runtime.openOptionsPage(); } catch (_) {} }
    else setBadge('');
  }, () => {});
});
browser.runtime.onStartup.addListener(() => { note('startup'); loop(); });

// 点图标（Android 上在菜单的「附加组件」里）：直接开设置页
// options_ui 是 Firefox for Android 上唯一可靠的入口，data: 页在部分版本会被拦。
browser.browserAction.onClicked.addListener(async () => {
  try {
    await browser.runtime.openOptionsPage();
  } catch (e) {
    console.warn('[bb] openOptionsPage failed', e && e.message);
  }
});

/* 状态页 -> 后台：配对 / 解除配对 */
browser.runtime.onMessage.addListener((m, sender, reply) => {
  if (!m || !m.type) return;
  if (m.type === 'bb-pair') {
    pair(m.code).then(
      async (j) => { loop(); reply({ ok: true, sid: j.sid }); },
      (e) => reply({ ok: false, error: e.message })
    );
    return true;
  }
  /* 设置页自己完成配对后发来的：只让它重读令牌、把轮询拉起来。
   * 回话可能到不了（消息通道有时不回），所以调用方不等它。 */
  if (m.type === 'bb-reload') {
    loadToken().then(() => { running = false; loop(); reply && reply({ ok: true }); },
      () => { loop(); reply && reply({ ok: false }); });
    return true;
  }
  if (m.type === 'bb-unpair') {
    clearToken().then(() => { running = false; reply({ ok: true }); });
    return true;
  }
});

note('boot', SID, BB_BASE);
loop();