#!/usr/bin/env node
'use strict';
/*
 * 许可：MIT License（Copyright (c) 2026 dsh-go-browse-use contributors），全文见同目录 LICENSE.txt。
 *
 * browser-bridge / bridge.js
 *
 * 既能独立跑（node bridge.js），也能被 dsh-go 插件 import 后在同一进程里起。
 *
 * 协议（全部 JSON，鉴权见 authOk）：
 *   GET  /health              -> {online, polling, paired, served, ...}
 *   POST /pair   {code,sid}   -> 配对码换令牌（唯一免鉴权的写接口）
 *   GET  /poll?sid=X          -> 长轮询取命令，25s 空转 204
 *   POST /result {id,ok,data|error}  <- 扩展回报
 *   POST /rpc    {cmd,args,timeout}  -> 我发起命令，同步等结果
 *   GET  /paircode            -> 当前配对码
 *   GET  /tokens              -> 已配对实例
 *   POST /revoke {token|all}  -> 吊销
 *
 * 安全：令牌每装一次唯一；Origin 非 moz-extension:// 一律 403（防网页 CSRF）。
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const VERSION = '1.1.0';
const POLL_WAIT_MS = 25000;
const DEFAULT_RPC_TIMEOUT = 30000;
const PAIR_TTL_MS = 10 * 60 * 1000;
/* 令牌寿命：到期后扩展必须重新换一枚，避免一枚令牌永久有效。
 * 扩展侧会在收到 token-expired 后自动重新配对。 */
const TOKEN_TTL_MS = Number(process.env.BB_TOKEN_TTL_MS || 24 * 60 * 60 * 1000);

/* 值永远不出桥接进程的命令。结果在这里被剥掉字段，工具层也拿不到原值。
 * 这是最后一道闸：即使扩展被改坏、或者有人绕过工具直接调 /rpc，也拿不到。 */
const SECRET_FIELDS = new Set(['value', 'pairs', 'cookie', 'set-cookie']);

/* 分级授权表。
 * auto  —— 只给元数据（标题/URL/链接/元素清单），不需要授权
 * grant —— 要「这个站点」的一次授权，记住 1 小时，期间不再问
 * call  —— 每次都要现问，不记住（任意代码执行、导出 cookie 值）
 * 没列在表里的一律按 grant 处理：宁可多问一句。 */
const SENSITIVE = {
  /* 导出 cookie 值：值写进 jar.json（0600），回模型的只有
   * {host,count,names,bytes} —— 一个字的值都不进上下文。 */
  'cookies.jar': { scope: 'cookies', mode: 'call', label: '导出 cookie 值（落盘，不进上下文）' },
  /* net.fetch：以「这个站点的身份」发请求 —— 浏览器自己带上 cookie。
   * 危险程度和读页面一样（读到的就是登录后的内容），所以按站点记一次授权。 */
  'net.fetch': { scope: 'net', mode: 'grant', label: '用本机浏览器身份请求一个网址' },
  /* page.eval 是唯一能绕过脱敏的通道：在页面里 document.cookie 就能把
   * 凭据原值直接拿进上下文。其它所有命令要么只读元数据、要么结果都过脱敏。
   * 所以宽松模式也只放开它 —— 每一次都问。 */
  'page.eval': { scope: 'eval', mode: 'call', label: '在页面里执行任意代码', strict: true },
  /* 导航会离开当前页面：按站点记 1 小时，同一个站内连续翻页不用反复问。 */
  'nav.goto': { scope: 'nav', mode: 'grant', label: '导航到新页面' },
  'nav.probe': { mode: 'auto' },
  'diag.log': { mode: 'auto' },
  /* 标记只是给被控制的标签加个标题前缀和橙点，不读不写数据 */
  'page.mark': { mode: 'auto' },
  'page.unmark': { mode: 'auto' },
  /* 顶边流动光效条：纯 CSS 装饰，只改 DOM，不读数据 */
  'page.bar': { mode: 'auto' },
  /* 呼吸光环：纯 CSS 装饰，只改 DOM，不读数据 */
  'page.ring': { mode: 'auto' },
  /* 选/放 AI 专用标签：只改浏览器状态，不读数据 */
  'tab.agent': { mode: 'auto' },
  /* 标签组「收纳」：只改标签的组织方式，不读数据也不改页面内容。
   * 桌面浏览器才有这个 API；手机/平板上扩展会回一句说明。 */
  'tab.group': { mode: 'auto' },
  /* 只动滚动位置 / 只等待条件成立，不改页面内容 */
  'page.scrollTo': { mode: 'auto' },
  'page.waitFor': { mode: 'auto' },
  /* 在页面上放出「请你接管」横幅，不读数据也不改表单 */
  'page.help': { mode: 'auto' },
  /* 以下会改页面状态或影响页面行为：按站点授权一次 */
  'page.press': { scope: 'act', mode: 'grant', label: '按键（可能触发表单提交）' },
  'page.select': { scope: 'act', mode: 'grant', label: '选择下拉项' },
  'page.dialog': { scope: 'act', mode: 'grant', label: '接管页面弹窗' },
  /* click / fill 会真的改动页面状态（能点掉确认、能往密码框里写值），
   * 必须和 press / select 同级：按站点授权一次，不是免审批直通。 */
  'page.click': { scope: 'act', mode: 'grant', label: '点击页面元素' },
  'page.fill': { scope: 'act', mode: 'grant', label: '填写页面输入框' },
  'page.observe': { scope: 'read', mode: 'grant', label: '读取页面概况与快照' },
  'nav.back': { scope: 'nav', mode: 'grant', label: '后退' },
  'nav.forward': { scope: 'nav', mode: 'grant', label: '前进' },
  'diag.clear': { mode: 'auto' },
  'page.text': { scope: 'read', label: '读取页面正文' },
  'page.html': { scope: 'read', label: '读取页面源码' },
  'page.query': { scope: 'read', label: '读取页面元素' },
  'page.snapshot': { scope: 'read', label: '读取页面可交互元素快照' },
  'page.links': { mode: 'auto' },
  'page.info': { mode: 'auto' },
  'page.meta': { mode: 'auto' },
  /* 只动滚动位置 / 只等待条件成立，不改页面内容 */
  'page.scroll': { mode: 'auto' },
  'page.wait': { mode: 'auto' },
  /* tab.open 新建标签页：会改变浏览器状态，但不改任何页面内容 */
  'tab.open': { mode: 'auto' },
  'tab.close': { mode: 'auto' },
  'tab.activate': { mode: 'auto' },
  'tab.reload': { mode: 'auto' },
  'cookies.get': { mode: 'auto' },
  'tabs.list': { mode: 'auto' },
  'tab.get': { mode: 'auto' },
  'ping': { mode: 'auto' },
  screenshot: { scope: 'shot', label: '截屏' },
  'history.search': { scope: 'history', label: '读取浏览历史' },
  'bookmarks.search': { scope: 'bookmarks', label: '读取书签' },
  'extract.emails': { scope: 'read', label: '抽取页面邮箱' },
  'extract.phones': { scope: 'read', label: '抽取页面电话' },
};
/* 没写 mode 的一律按 grant：宁可多问一次，也不要默默放过。 */
for (const k of Object.keys(SENSITIVE)) {
  const r = SENSITIVE[k];
  if (!r.mode) r.mode = 'grant';
  if (!r.label) r.label = k;
}

const GRANT_TTL_MS = Number(process.env.BB_GRANT_TTL_MS || 60 * 60 * 1000);
const APPROVAL_WAIT_MS = Number(process.env.BB_APPROVAL_WAIT_MS || 120000);
/* 超过这个字节数就不进上下文，改写成「转发到文件 + 摘要」 */
const FORWARD_THRESHOLD = Number(process.env.BB_FORWARD_THRESHOLD || 2000);

/* ---------- 状态文件 ---------- */

function makeStore(dir) {
  const ensureDir = () => { try { fs.mkdirSync(dir, { recursive: true }) } catch (_) {} };
  ensureDir();
  const TOKENS_FILE = path.join(dir, 'tokens.json');
  const PAIR_FILE = path.join(dir, 'paircode.json');

  function loadTokens() {
    try {
      const j = JSON.parse(fs.readFileSync(TOKENS_FILE, 'utf8'));
      if (j && typeof j === 'object' && !Array.isArray(j)) return j;
    } catch (_) {}
    return {};
  }
  function saveTokens(t) {
    // 目录可能被外部删掉（检查器用临时 HOME、用户清缓存），写之前再确保一次。
    try {
      ensureDir();
      fs.writeFileSync(TOKENS_FILE, JSON.stringify(t, null, 2) + '\n', { mode: 0o600 });
    } catch (_) { /* 落盘失败不该让桥接崩：内存态仍然可用 */ }
  }
  function loadPair() {
    try {
      const j = JSON.parse(fs.readFileSync(PAIR_FILE, 'utf8'));
      if (j && j.code) return j;
    } catch (_) {}
    return null;
  }
  function savePair(p) {
    try {
      ensureDir();
      fs.writeFileSync(PAIR_FILE, JSON.stringify(p, null, 2) + '\n', { mode: 0o600 });
    } catch (_) { /* 同上 */ }
  }
  return { dir, loadTokens, saveTokens, loadPair, savePair };
}

/* ---------- cookie jar：值只在这里，永不回传 ---------- */

function makeJar(dir) {
  const FILE = path.join(dir, 'jar.json');
  let J = {};
  try {
    const raw = JSON.parse(fs.readFileSync(FILE, 'utf8'));
    if (raw && typeof raw === 'object' && !Array.isArray(raw)) J = raw;
  } catch (_) {}

  const persist = () => {
    try {
      fs.mkdirSync(dir, { recursive: true });
      fs.writeFileSync(FILE, JSON.stringify(J, null, 2) + '\n', { mode: 0o600 });
    } catch (_) {}
  };

  /** 收下扩展报来的全值，只留在本进程 + 0600 文件里 */
  function absorb(url, pairs) {
    let host = '';
    try { host = new URL(url).host; } catch (_) { host = String(url || ''); }
    const list = (pairs || []).map((c) => ({
      name: String(c.name || ''),
      value: String(c.value == null ? '' : c.value),
      domain: String(c.domain || host),
      path: String(c.path || '/'),
    })).filter((c) => c.name);
    J[host] = { host, at: new Date().toISOString(), cookies: list };
    persist();
    return {
      host,
      count: list.length,
      // 回给模型的是这个：足够判断 jar 里有什么，但推不回值
      names: list.map((c) => c.name),
      bytes: list.reduce((n, c) => n + c.name.length + c.value.length, 0),
    };
  }

  function headerFor(u) {
    let host = '';
    try { const p = new URL(u); host = p.host; } catch (_) { return ''; }
    const e = J[host];
    if (!e) return '';
    return e.cookies.map((c) => `${c.name}=${c.value}`).join('; ');
  }

  function summary() {
    return Object.keys(J).map((h) => ({
      host: h, count: J[h].cookies.length, at: J[h].at,
      names: J[h].cookies.map((c) => c.name),
    }));
  }

  function clear(h) {
    if (h === 'all' || !h) { J = {}; persist(); return true; }
    if (J[h]) { delete J[h]; persist(); return true; }
    return false;
  }

  return { absorb, headerFor, summary, clear, file: FILE };
}

/* ---------- 授权：待批队列 + 站点授权 ---------- */

function makeGrants(dir) {
  const FILE = path.join(dir, 'grants.json');
  let G = {};
  try {
    const raw = JSON.parse(fs.readFileSync(FILE, 'utf8'));
    if (raw && typeof raw === 'object' && !Array.isArray(raw)) G = raw;
  } catch (_) {}

  /* 磁盘热加载：grants.json 改了就能生效，不用重启桥接。
   * 之前只在启动时读一次，改了授权文件必须 off/on 重来 ——
   * 而重启会掐掉正在等待的命令。 */
  let lastMtime = 0;
  function reloadFromDisk() {
    try {
      const st = fs.statSync(FILE);
      const mt = st.mtimeMs;
      if (mt === lastMtime) return;
      lastMtime = mt;
      const raw = JSON.parse(fs.readFileSync(FILE, 'utf8'));
      if (raw && typeof raw === 'object' && !Array.isArray(raw)) G = raw;
    } catch (_) { /* 文件没了或坏了就保持现状 */ }
  }
  try { lastMtime = fs.statSync(FILE).mtimeMs } catch (_) { lastMtime = 0 }

  const persist = () => {
    try {
      fs.mkdirSync(dir, { recursive: true });
      fs.writeFileSync(FILE, JSON.stringify(G, null, 2) + '\n', { mode: 0o600 });
    } catch (_) {}
  };

  /** 待批请求：id -> {resolve, at, ...}。面板读 pending、用户点批准后 resolve。 */
  const pending = new Map();
  let seq = 0;

  function keyOf(scope, site) { return `${scope}@${site || '*'}`; }

  function granted(scope, site) {
    return grantsStatus(scope, site).state === 'granted';
  }

  /* 授权状态分三种：granted（还有效）/ expired（曾经授权、过期了）/
   * none（从来没授权过）。
   * 分开是为了让报错能说人话 —— 之前过期也报「未授权」，
   * 排查的人根本看不出是过期还是压根没批过。 */
  function grantsStatus(scope, site) {
    reloadFromDisk();
    const now = Date.now();
    const keys = [keyOf(scope, site), keyOf(scope, '*')];
    let expired = null;
    for (const k of keys) {
      const e = G[k];
      if (!e || !e.until) continue;
      if (now < e.until) return { state: 'granted', until: e.until, site: e.site };
      if (!expired) expired = { state: 'expired', until: e.until, site: e.site };
    }
    return expired || { state: 'none', until: 0, site: site || '*' };
  }

  function remember(scope, site, ttlMs) {
    reloadFromDisk();
    const k = keyOf(scope, site);
    /* 已有授权不许被缩短：否则用户手动给了 30 天的授权，
     * 一次 hostApproved 调用就把它冲回 1 小时。取两者里更晚的那个。
     * ttlMs 传 null 表示「沿用已有的到期时间，不重新计时」。 */
    const prev = G[k];
    const base = Date.now() + (ttlMs === null ? 0 : (ttlMs || GRANT_TTL_MS));
    const until = prev && prev.until > Date.now()
      ? Math.max(prev.until, base)
      : base;
    G[k] = { scope, site: site || '*', until, at: new Date().toISOString() };
    persist();
  }

  function revoke(scope, site) {
    reloadFromDisk();
    const k = keyOf(scope, site);
    if (!G[k]) return false;
    delete G[k]; persist(); return true;
  }

  function revokeAll() { G = {}; persist(); return true; }

  function list() {
    reloadFromDisk();
    const now = Date.now();
    return Object.keys(G)
      .filter((k) => G[k].until > now)
      .map((k) => ({ scope: G[k].scope, site: G[k].site, minutesLeft: Math.round((G[k].until - now) / 60000) }));
  }

  /** 挂一条待批，等用户点。超时算拒绝。 */
  function ask(req) {
    const id = 'ap' + (++seq) + '_' + crypto.randomBytes(3).toString('hex');
    return new Promise((resolve) => {
      const timer = setTimeout(() => {
        if (pending.has(id)) { pending.delete(id); resolve({ ok: false, reason: 'timeout' }); }
      }, APPROVAL_WAIT_MS);
      pending.set(id, {
        id, at: new Date().toISOString(), timer,
        cmd: req.cmd, scope: req.scope, site: req.site, kind: req.mode,
        label: req.label || req.cmd,
        approve: (rememberIt) => {
          if (!pending.has(id)) return false;
          const p = pending.get(id);
          clearTimeout(p.timer); pending.delete(id);
          /* call 级（eval / raw / cookies.jar）永远不落授权：
           * 每次都要现问，否则「批准一次」就等于拿到 1 小时的免问通行证。 */
          const canRemember = req.mode !== 'call';
          if (rememberIt && canRemember) remember(req.scope, req.site);
          resolve({ ok: true, remembered: !!(rememberIt && canRemember) });
          return true;
        },
        deny: () => {
          if (!pending.has(id)) return false;
          const p = pending.get(id);
          clearTimeout(p.timer); pending.delete(id);
          resolve({ ok: false, reason: 'denied' });
          return true;
        },
      });
    });
  }

  function pendingList() {
    return Array.from(pending.values()).map((p) => ({
      id: p.id, cmd: p.cmd, scope: p.scope, site: p.site, kind: p.kind,
      label: p.label, at: p.at,
    }));
  }

  /* 不阻塞地挂一条待批：只登记到面板队列，不等结果。
   * 用来「先告诉调用方需要授权，等用户在面板批了再重发」——
   * 阻塞式 ask() 会让调用方先超时，把「没授权」表现成「静默挂住」。 */
  function enqueue(req) {
    const id = 'ap' + (++seq) + '_' + crypto.randomBytes(3).toString('hex');
    const timer = setTimeout(() => {
      if (pending.has(id)) { pending.delete(id); }
    }, APPROVAL_WAIT_MS);
    pending.set(id, {
      id, at: new Date().toISOString(), timer,
      cmd: req.cmd, scope: req.scope, site: req.site, kind: req.mode,
      label: req.label || req.cmd,
      approve: (rememberIt) => {
        if (!pending.has(id)) return false;
        const p = pending.get(id);
        clearTimeout(p.timer); pending.delete(id);
        /* call 级（eval / raw / cookies.jar）永远不落授权 */
        const canRemember = req.mode !== 'call';
        if (rememberIt && canRemember) remember(req.scope, req.site);
        return true;
      },
      deny: () => {
        if (!pending.has(id)) return false;
        const p = pending.get(id);
        clearTimeout(p.timer); pending.delete(id);
        return true;
      },
    });
    return id;
  }

  return { granted, grantsStatus, remember, revoke, revokeAll, list, ask, enqueue, pendingList, pending };
}

/* ---------- 转发：大块内容不进口袋，落盘 + 摘要 ---------- */

function makeSink(dir) {
  const D = path.join(dir, 'forward');
  function put(name, body) {
    try {
      fs.mkdirSync(D, { recursive: true });
      const safe = String(name || 'blob').replace(/[^\w.\-]+/g, '_').slice(0, 60);
      const fp = path.join(D, `${Date.now()}-${safe}`);
      fs.writeFileSync(fp, String(body ?? ''), { mode: 0o600 });
      return fp;
    } catch (_) { return null; }
  }
  /* 预览的第一行常常是导航栏、登录入口、站点口号 —— 那是全文里最没用的部分，
   * 却占掉了预览的全部空间。这里跳过明显的导航/页眉行，
   * 尽量让预览落在正文的第一句上。 */
  const NAV_HINT = /^(首页|登录|注册|导航|搜索|更多|English|中文|简体|繁體|站内|返回|上一篇|下一篇|目录|主页|商城|客服|关于我们|隐私|版权|广告|当前位置|您所在位置|\s*$)/;
  function pickHead(lines) {
    const clean = lines.map((l) => l.trim()).filter(Boolean);
    const good = clean.find((l) => !NAV_HINT.test(l) && l.length > 12);
    return (good || clean[0] || '').slice(0, 160);
  }
  function summaryOf(s) {
    const str = String(s ?? '');
    const lines = str.split('\n');
    const clean = lines.map((l) => l.trim()).filter(Boolean);
    const good = clean.filter((l) => !NAV_HINT.test(l));
    const preview = (good.length ? good : clean).slice(0, 6).join(' \u00b7 ').slice(0, 400);
    return {
      bytes: Buffer.byteLength(str),
      lines: lines.length,
      preview,
      head: pickHead(lines),
    };
  }
  return { put, summaryOf, dir: D };
}

/* ---------- 出站结果消毒：兜底，不依赖扩展自律 ---------- */

function scrubSecrets(data, depth) {
  depth = depth || 0;
  if (depth > 12) return '[too deep]';
  if (data === null || typeof data !== 'object') return data;
  if (Array.isArray(data)) return data.map((x) => scrubSecrets(x, depth + 1));
  const out = {};
  for (const k of Object.keys(data)) {
    if (SECRET_FIELDS.has(String(k).toLowerCase())) continue; // 直接删字段，不给占位
    out[k] = scrubSecrets(data[k], depth + 1);
  }
  return out;
}

/* ---------- 主入口 ---------- */

/**
 * @param {object} opts
 * @param {number} [opts.port=8765]
 * @param {string} [opts.host='127.0.0.1']
 * @param {string} [opts.dataDir]  令牌/配对码存放目录
 * @param {(line:string)=>void} [opts.log]
 * @returns {Promise<{port:number, close:()=>Promise<void>, state:object, api:object}>}
 */
function startBridge(opts) {
  const o = opts || {};
  const PORT = Number(o.port || process.env.BB_PORT || 8790);
  const HOST = o.host || '127.0.0.1';
  const store = makeStore(o.dataDir || path.join(process.cwd(), 'bb-data'));
  const log = o.log || ((...a) => console.log('[bb]', ...a));

  const jar = makeJar(store.dir);
  const grants = makeGrants(store.dir);
  const sink = makeSink(store.dir);

  /* ---------- 宽松模式（默认开） ----------
   *
   * 浏览器操控本身没什么破坏性：读页面、点按钮、填表单、导航、截图，
   * 结果都已经过脱敏（扩展侧 redact.js + 桥接侧 scrubSecrets）。
   * 所以默认不再逐站点问「要不要授权」。
   *
   * 仍然要问的只有两类（mode = call）：
   *   - 在页面里执行任意代码（page.eval / raw）
   *   - 导出 cookie 的真值（cookies.jar）
   * 这两个能拿到凭据本身，不是「操控浏览器」。
   *
   * mode.json 里写 {"relax": false} 就回到严格模式（逐站点问）。
   * 面板上有个开关可以直接切。 */
  const MODE_FILE = path.join(store.dir, 'mode.json');
  let relaxCache = { at: 0, v: true };
  function isRelaxed() {
    try {
      const st = fs.statSync(MODE_FILE);
      if (st.mtimeMs === relaxCache.at) return relaxCache.v;
      const j = JSON.parse(fs.readFileSync(MODE_FILE, 'utf8'));
      relaxCache = { at: st.mtimeMs, v: j && j.relax === false ? false : true };
    } catch {
      /* 文件不存在 = 默认宽松 */
      if (relaxCache.at !== -1) relaxCache = { at: -1, v: true };
    }
    return relaxCache.v;
  }
  let TOKENS = store.loadTokens();

  /* 老版本发的令牌没有 exp 字段，那样永远不会过期。加载时补一个：
   * 从「现在」起算一个 TTL —— 不追溯惩罚，也不让它无限期有效。 */
  {
    let patched = 0;
    for (const tok of Object.keys(TOKENS)) {
      const m = TOKENS[tok];
      if (m && typeof m === 'object' && !m.exp) { m.exp = Date.now() + TOKEN_TTL_MS; patched++; }
    }
    if (patched) store.saveTokens(TOKENS);
  }

  /* 配对码：终端/面板可见，10 分钟一次性 */
  let PAIR = store.loadPair() || { code: null, exp: 0, used: true };

  function genPairCode() {
    const code = String(Math.floor(100000 + Math.random() * 900000));
    PAIR = { code, exp: Date.now() + PAIR_TTL_MS, used: false };
    store.savePair(PAIR);
    return code;
  }
  function pairCodeValid(code) {
    if (!PAIR.code || PAIR.used) return false;
    if (Date.now() > PAIR.exp) return false;
    return String(code).trim() === PAIR.code;
  }
  function currentPairCode() {
    if (!PAIR.code || PAIR.used || Date.now() > PAIR.exp) genPairCode();
    return { code: PAIR.code, expiresInSec: Math.max(0, Math.round((PAIR.exp - Date.now()) / 1000)) };
  }

  function mintToken(sid) {
    const tok = crypto.randomBytes(24).toString('hex');
    const now = Date.now();
    TOKENS[tok] = {
      sid: String(sid || 'unknown').slice(0, 64),
      createdAt: new Date(now).toISOString(),
      exp: now + TOKEN_TTL_MS,
      label: '未命名实例 ' + String(sid || '?').slice(0, 6),
    };
    store.saveTokens(TOKENS);
    return tok;
  }
  /* 过期令牌就地清理，顺手把文件写回，免得 tokens.json 越积越大。 */
  function pruneExpired() {
    let n = 0;
    const now = Date.now();
    for (const tok of Object.keys(TOKENS)) {
      if (TOKENS[tok].exp && now > TOKENS[tok].exp) { delete TOKENS[tok]; n++; }
    }
    if (n) store.saveTokens(TOKENS);
    return n;
  }
  function tokenExpired(tok) {
    const m = TOKENS[tok];
    return !!(m && m.exp && Date.now() > m.exp);
  }
  function revokeToken(pref) {
    if (pref === 'all') {
      const n = Object.keys(TOKENS).length;
      TOKENS = {};
      store.saveTokens(TOKENS);
      return n;
    }
    const p = String(pref || '').replace('…', '').trim();
    // 空前缀会把「第一个令牌」当成命中（startsWith('') 恒真），必须挡住：
    // 面板里拿不到 token 时就会传空串，不清空列表反而误删一个。
    if (!p) return 0;
    for (const tok of Object.keys(TOKENS)) {
      if (tok === p || tok.startsWith(p)) {
        delete TOKENS[tok];
        store.saveTokens(TOKENS);
        return 1;
      }
    }
    return 0;
  }

  const state = {
    started: Date.now(),
    queue: [],
    waiter: null,
    pending: new Map(),
    lastSeen: 0,
    lastPollAt: 0,
    lastAuthFailAt: 0,
    sid: null,
    served: 0,
    polling: false,
    lastCmd: null,
    lastSite: null,
    lastBadOrigin: null,
    extVer: null,
    extName: null,
    lastPollToken: null,
    /* 操作日志：最近 N 条命令的「时间 · 命令 · 结果」。
     * 面板底部那块固定高度的文本块直接显示它 —— 既有记录，
     * 又不用另开一个折叠区把面板撑长。 */
    log: [],
  };
  const LOG_MAX = 200;
  /* ok 是三态：'pending'（已下发，结果还没回来）/ 'ok' / 'fail'。
   * 用字符串而不是布尔，是为了能区分「还没回包」和「成功了」——
   * 超时的命令结果永远不回来，那条会一直停在 pending。 */
  function pushLog(cmd, ok, note) {
    state.log.push({
      at: new Date().toISOString(),
      cmd: String(cmd || ''),
      ok: ok || 'pending',
      note: note ? String(note).slice(0, 80) : '',
    });
    if (state.log.length > LOG_MAX) state.log.splice(0, state.log.length - LOG_MAX);
  }
  /* 找到那条 pending 的日志并改写它（结果回来 / 超时 都走这里） */
  function settleLog(cmd, ok, note) {
    for (let i = state.log.length - 1; i >= 0; i--) {
      const l = state.log[i];
      if (l.ok === 'pending' && l.cmd === String(cmd || '')) {
        l.ok = ok ? 'ok' : 'fail';
        l.note = note ? String(note).slice(0, 80) : '';
        l.at = new Date().toISOString();
        return true;
      }
    }
    return false;
  }

  function send(res, code, obj) {
    const body = obj === undefined ? '' : JSON.stringify(obj);
    const h = {
      'Content-Type': 'application/json; charset=utf-8',
      'Content-Length': Buffer.byteLength(body),
      'Cache-Control': 'no-store',
    };
    /* Chromium 扩展（MV3）的 fetch 会带 chrome-extension:// 的 Origin，
     * 走到本地地址时可能先发预检、并按 Private Network Access 要求应答。
     * Firefox 的 moz-extension:// 不走预检，这里多发的头对它无副作用。 */
    const org = res.__bbOrigin;
    if (org && isExtOrigin(org)) {
      h['Access-Control-Allow-Origin'] = org;
      h['Access-Control-Allow-Methods'] = 'GET, POST, OPTIONS';
      h['Access-Control-Allow-Headers'] = 'content-type, x-bb-token';
      h['Access-Control-Max-Age'] = '600';
      if (res.__bbPna) h['Access-Control-Allow-Private-Network'] = 'true';
    }
    res.writeHead(code, h);
    res.end(body);
  }

  function readBody(req, limit = 32 * 1024 * 1024) {
    return new Promise((resolve, reject) => {
      const chunks = [];
      let size = 0;
      req.on('data', (c) => {
        size += c.length;
        if (size > limit) { reject(new Error('body too large')); req.destroy(); return; }
        chunks.push(c);
      });
      req.on('end', () => {
        const raw = Buffer.concat(chunks).toString('utf8');
        if (!raw) return resolve({});
        try { resolve(JSON.parse(raw)); } catch (e) { reject(new Error('bad json: ' + e.message)); }
      });
      req.on('error', reject);
    });
  }

  /* Firefox 是 moz-extension://，Chromium/Edge/Vivaldi 是 chrome-extension://。
   * 网页带不出这两种 scheme，所以它仍然是有效的「非网页来源」判据。 */
  function isExtOrigin(o) {
    const s2 = String(o || '');
    return s2.startsWith('moz-extension://') || s2.startsWith('chrome-extension://');
  }

  function authOk(req) {
    const origin = req.headers.origin;
    if (origin && !isExtOrigin(origin)) {
      state.lastBadOrigin = { origin: String(origin).slice(0, 80), at: new Date().toISOString(), via: 'auth' };
      return 'bad-origin';
    }
    const tok = req.headers['x-bb-token'];
    if (!tok || !TOKENS[tok]) return 'bad-token';
    if (tokenExpired(tok)) { delete TOKENS[tok]; store.saveTokens(TOKENS); return 'token-expired'; }
    return null;
  }

  function isOnline() {
    pruneExpired();
    const ref = Math.max(state.lastSeen || 0, state.lastPollAt || 0);
    if (!ref) return false;
    if (Date.now() - ref > 90000) return false;
    if (state.lastAuthFailAt > ref) return false;
    return Object.keys(TOKENS).length > 0;
  }

  function flushWaiter() {
    if (!state.waiter || !state.queue.length) return false;
    const w = state.waiter;
    state.waiter = null;
    clearTimeout(w.timer);
    state.polling = false;
    send(w.res, 200, state.queue.shift());
    return true;
  }

  function health() {
    return {
      version: VERSION,
      online: isOnline(),
      polling: !!state.polling,
      paired: Object.keys(TOKENS).length,
      served: state.served,
      queued: state.queue.length,
      pending: state.pending.size,
      sid: state.sid,
      lastSeenAgoSec: state.lastPollAt ? Math.round((Date.now() - state.lastPollAt) / 1000) : null,
      lastCmd: state.lastCmd,
      /* 操作日志：面板底部那块固定高度文本块显示它 */
      log: state.log.slice(-40).reverse(),
      /* 最近一次被来源校验拒掉的请求 —— 排查「扩展连不上」时先看这里：
       * 出现 chrome-extension:// 说明桥接还在跑旧代码（不认 Chromium 来源）。 */
      lastBadOrigin: state.lastBadOrigin,
      extVer: state.extVer,
      extName: state.extName,
      tokenTtlSec: Math.round(TOKEN_TTL_MS / 1000),
      uptimeSec: Math.round((Date.now() - state.started) / 1000),
    };
  }

  /* ---------- RPC ---------- */

  function siteOf(args) {
    const a = args || {};
    const raw = a.site || a.url || a.__site;
    if (raw) {
      try { return new URL(String(raw)).host; } catch (_) {
        const m = String(raw).match(/^([\w.-]+\.[a-z]{2,})/i);
        if (m) return m[1];
      }
    }
    return state.lastSite || null;
  }

  /* 授权闸：在命令进队列之前过一道。
   *
   * 两条入口：
   *   hostApproved=true —— 插件侧的 tools/pre-execute 已经让用户在 App 原生
   *     审批框里点过「允许」，这里只补记站点授权，不再问第二遍。
   *   其余（HTTP /rpc，bb.js CLI 走这条）—— 用桥接自己的待批队列。
   *
   * auto 直接过；grant 看有没有记住；call 每次都问。
   */
  async function rpcGated(cmd, args, timeout, opts) {
    let rule = SENSITIVE[cmd];
    /* 表里没有的命令：一律按 grant 处理（宁可多问一句）。
     * 之前这里是直接放行，跟表头的注释正好相反 ——
     * 结果就是「漏登记一条命令 = 静默无授权执行」，click/fill 就这么漏的。 */
    const known = !!SENSITIVE[cmd];
    if (!rule) rule = { scope: cmd, mode: 'grant', label: '未登记的命令：' + cmd };
    if (rule.mode === 'auto') return rpc(cmd, args, timeout);
    const site = siteOf(args) || '*';

    /* 宽松模式（默认）：表里登记过的命令直接放行，不问、不记授权。
     * 只有标了 strict 的（page.eval）仍然每次问 —— 那是唯一能绕过脱敏的通道。
     * 未登记的命令仍然要问，否则新加一条忘了登记 = 静默无授权执行。 */
    if (known && isRelaxed() && !rule.strict) {
      return rpc(cmd, args, timeout);
    }

    if (opts && opts.hostApproved === true) {
      /* 显式传 ttl：默认 GRANT_TTL_MS 会把用户手动给的长授权缩短。
       * 传 null 表示「不改动已有授权的到期时间」。 */
      if (rule.mode === 'grant') grants.remember(rule.scope || cmd, site, opts.grantTtlMs === undefined ? undefined : opts.grantTtlMs);
      return rpc(cmd, args, timeout);
    }

    /* 插件侧已经判定「这个会话弹不出原生审批窗」（策略 never-ask），
     * 于是把决定权交给桥接自己的待批队列 —— 面板里能看见、能点批准。
     * 这一步必须真的问，不能因为 hostApproved=false 就放行。
     *
     * 但**不能阻塞等**：之前这里是 await grants.ask()（最长 120 秒），
     * 而调用方 16 秒就超时了 —— 于是「没授权」被表现成「静默超时 30 秒」，
     * /health 里 pending/queued 都是 0、lastCmd 还停在上一条，
     * 调用方完全查不出原因（实测清单 #15）。
     *
     * 现在改成：立刻返回结构化的「需要授权」，同时把待批条目挂进面板队列。
     * 用户在面板点批准后，这条 scope+site 就被记住，重发一次即可。 */
    if (opts && opts.deferToQueue === true) {
      if (rule.mode === 'grant' && grants.granted(rule.scope, site)) {
        return rpc(cmd, args, timeout);
      }
      const st0 = grants.grantsStatus(rule.scope, site);
      /* 挂一条待批（面板里会显示、可点批准），但不阻塞等它 */
      const pendingId = grants.enqueue({
        cmd, scope: rule.scope || cmd, site, mode: rule.mode,
        label: rule.label || cmd,
      });
      return {
        ok: false,
        error: `需要授权：${rule.label || cmd}（scope ${rule.scope || cmd}，站点 ${site}）`,
        code: st0.state === 'expired' ? 'APPROVAL_EXPIRED' : 'APPROVAL_REQUIRED',
        needApproval: true,
        pendingId,
        scope: rule.scope || cmd,
        site,
        hint: '在插件面板的「待批准的访问」里点允许，然后重发这一条。'
          + (st0.state === 'expired' ? '（这条站点的授权已经过期了，重新批一次就好。）' : ''),
      };
    }

    const st = grants.grantsStatus(rule.scope, site);
    if (rule.mode === 'grant' && st.state === 'granted') {
      return rpc(cmd, args, timeout);
    }
    const verdict = await grants.ask({
      cmd, scope: rule.scope || cmd, site, mode: rule.mode,
      label: rule.label || cmd,
    });
    if (!verdict.ok) {
      return approvalDenied(rule, site, verdict.reason, st);
    }
    return rpc(cmd, args, timeout);
  }

  /* 授权没通过：给出结构化原因，调用方一眼能看出是「过期」还是「没批过」。
   * 文案必须自解释 —— 「the user rejected tool browser」这种
   * 会让人以为用户真按了拒绝，实际上用户一次都没点过。 */
  function approvalDenied(rule, site, reason, prior) {
    const scope = rule.scope || rule.cmd;
    const label = rule.label || rule.cmd;
    const wasExpired = prior && prior.state === 'expired';
    const code = wasExpired ? 'APPROVAL_EXPIRED' : 'APPROVAL_REQUIRED';
    const tail = wasExpired
      ? `（${scope} 授权已过期）`
      : `（${scope} 还没授权）`;
    const err = reason === 'timeout'
      ? `授权超时（${Math.round(APPROVAL_WAIT_MS / 1000)} 秒内没批）：${label}${tail}`
      : `没有执行：${label}${tail}，站点 ${site}。在面板的「待批准的访问」里点允许，或把它记住。`;
    return {
      ok: false,
      error: err,
      code,
      needApproval: true,
      scope,
      site,
      hint: wasExpired
        ? '这条站点的授权已经过期了，重新批一次就好。'
        : '在插件面板的「待批准的访问」里可以批准这条请求。',
    };
  }

  /** 从待发队列里摘掉一条（超时/取消时用）。 */
  function dropQueued(id) {
    for (let i = state.queue.length - 1; i >= 0; i--) {
      if (state.queue[i] && state.queue[i].id === id) state.queue.splice(i, 1);
    }
  }

  function rpc(cmd, args, timeout) {
    if (!cmd) return Promise.resolve({ ok: false, error: 'cmd required' });
    const id = crypto.randomBytes(8).toString('hex');
    /* 上限 60s：nav.goto 之类要等页面加载的，45s 太紧 ——
     * 实测里导航本身成功了，只是回包没在窗口内回来，
     * 调用方一判失败就重试，标签越开越多。 */
    const t = Math.min(Number(timeout) || DEFAULT_RPC_TIMEOUT, 60000);
    const started = Date.now();
    state.lastCmd = { cmd, at: new Date().toISOString() };
    pushLog(cmd, 'pending', '下发');

    return new Promise((resolve) => {
      const timer = setTimeout(() => {
        if (state.pending.has(id)) {
          state.pending.delete(id);
          /* 超时也要把队列里的条目摘掉，否则它会一直挂着，
           * 等扩展哪天回来时把这条早已超时的命令再发一遍（/health 里 queued 永远 >0）。 */
          dropQueued(id);
          const ago = state.lastPollAt ? Math.round((Date.now() - state.lastPollAt) / 1000) : null;
          const polling = !!state.polling;
          let msg;
          let code;
          if (ago === null) {
            msg = '没有扩展连上来过：浏览器没开，或扩展没配对';
            code = 'NO_EXTENSION';
          } else if (!polling) {
            msg = `扩展 ${ago}s 前有心跳，但现在不在轮询（后台页被系统挂起，或令牌已吊销）`;
            code = 'SUSPENDED';
          } else {
            msg = '扩展正在轮询，但这条命令没在超时内返回（页面可能被挂起）';
            code = 'TIMEOUT';
          }
          settleLog(cmd, false, msg);
          resolve({
            ok: false, error: msg, code, retryable: true,
            online: isOnline(), polling, elapsedMs: Date.now() - started,
          });
        }
      }, t);

      state.pending.set(id, {
        cmd: String(cmd),
        args: args || {},
        res: (r) => resolve(Object.assign(r, { elapsedMs: Date.now() - started })),
        timer,
      });
      state.queue.push({ id, cmd, args: args || {}, ts: Date.now() });
      flushWaiter();
    });
  }

  /* ---------- 结果消毒：命令相关的定点处理 + 通用兜底 ---------- */

  function sanitizeResult(cmd, data, args) {
    if (!data || typeof data !== 'object') return data;
    let out = data;
    const a = args || {};

    /* cookies.jar：把值收进 jar，回传内容里不再有值 */
    if (cmd === 'cookies.jar' && Array.isArray(out.pairs)) {
      const info = jar.absorb(out.url, out.pairs);
      const rest = Object.assign({}, out);
      delete rest.pairs;
      delete rest.cookies;
      return Object.assign(rest, { jar: info });
    }

    out = scrubSecrets(out);

    /* 大块正文不进口袋：落盘 + 只回摘要。
     * text/html/源码动辄几十万字符，全塞进上下文等于把整页交出去，
     * 且很快撑爆窗口。这里换成「文件路径 + 行数 + 前几行」。 */
    for (const field of ['text', 'html', 'content', 'body']) {
      const v = out[field];
      if (typeof v !== 'string') continue;
      /* 强制落盘：用户要的是「AI 能把东西给你，但内容不进上下文」。
       * 这时连预览都不给 —— 一个字都不回，只给路径。 */
      const forced = a.forceFile === true;
      if (!forced && Buffer.byteLength(v) <= FORWARD_THRESHOLD) continue;
      const fp = sink.put(`${cmd.replace(/\W+/g, '-')}-${field}.txt`, v);
      const sm = sink.summaryOf(v);
      out[field] = forced
        ? `[已落盘，内容未进入上下文] ${fp || '(落盘失败)'}\n${sm.lines} 行 / ${sm.bytes} 字节`
        : `[已转发到文件，未进入上下文] ${fp || '(落盘失败)'}\n${sm.lines} 行 / ${sm.bytes} 字节\n首行：${sm.head}`;
      out.forwarded = { field, path: fp, bytes: sm.bytes, lines: sm.lines, preview: forced ? '' : sm.preview, forced };
    }
    return out;
  }

  /* ---------- 桥接侧代取：cookie 值不外泄的那条路 ---------- */

  async function jarFetch(target, opt) {
    const o = opt || {};
    let url;
    try { url = new URL(String(target)); } catch (_) { return { ok: false, error: 'bad url' }; }
    if (!/^https?:$/.test(url.protocol)) return { ok: false, error: 'only http(s)' };
    const cookie = jar.headerFor(url.href);
    const headers = Object.assign({ 'User-Agent': 'Mozilla/5.0 (Android 14; Mobile; rv:153.0) Gecko/153.0 Firefox/153.0' }, o.headers || {});
    if (cookie) headers.Cookie = cookie;
    const ctl = new AbortController();
    const t = setTimeout(() => ctl.abort(), Math.min(Number(o.timeout) || 30000, 60000));
    try {
      const r = await fetch(url.href, { headers, signal: ctl.signal, redirect: 'follow' });
      const ct = r.headers.get('content-type') || '';
      const buf = Buffer.from(await r.arrayBuffer());
      const ok = r.ok;
      const base = { ok, status: r.status, url: r.url, contentType: ct, bytes: buf.length, usedCookie: !!cookie };
      if (o.save) {
        /* 落盘模式：二进制（PDF/图片）不进上下文，只给路径 */
        const dir = o.saveDir || path.join(store.dir, 'downloads');
        fs.mkdirSync(dir, { recursive: true });
        const name = (o.name || path.basename(url.pathname) || 'download').replace(/[^\w.\-]+/g, '_').slice(0, 80);
        const fp = path.join(dir, name);
        fs.writeFileSync(fp, buf, { mode: 0o600 });
        return Object.assign(base, { path: fp });
      }
      const isText = /text|json|xml|javascript|html/i.test(ct);
      const body = isText ? buf.toString('utf8') : '';
      return Object.assign(base, isText ? { text: body.slice(0, Number(o.maxChars) || 200000) } : { note: '二进制，未回传；加 save:true 落盘拿路径' });
    } catch (e) {
      return { ok: false, error: e && e.message || String(e) };
    } finally { clearTimeout(t); }
  }

  /* ---------- 路由 ---------- */

  const server = http.createServer(async (req, res) => {
    const url = new URL(req.url, `http://${HOST}:${PORT}`);
    const p = url.pathname;

    res.__bbOrigin = req.headers.origin;
    res.__bbPna = !!req.headers['access-control-request-private-network'];

    /* Chromium 会为带自定义头的跨源请求发预检；只有扩展来源才放行。 */
    if (req.method === 'OPTIONS') {
      if (!isExtOrigin(req.headers.origin)) {
        state.lastBadOrigin = { origin: String(req.headers.origin || '(空)').slice(0, 80), at: new Date().toISOString(), via: 'preflight' };
        return send(res, 403, { error: 'bad-origin' });
      }
      return send(res, 204, undefined);
    }

    if (p === '/health') return send(res, 200, health());

    // 配对：不需要令牌，但要配对码 + 来源必须是扩展
    if (p === '/pair' && req.method === 'POST') {
      const origin = req.headers.origin;
      if (origin && !isExtOrigin(origin)) return send(res, 403, { error: 'bad-origin' });
      let body;
      try { body = await readBody(req); } catch (e) { return send(res, 400, { error: e.message }); }
      const sid = String(body.sid || 'unknown').slice(0, 64);
      // 扩展后台页 fetch 到 127.0.0.1 时 Origin 是 moz-extension://<uuid>；个别版本不带 Origin。
      // 网页发起的跨源请求（fetch/XHR/form）一定会带 Origin，所以「没有 Origin」可视为非网页上下文。
      const isExt = !origin || isExtOrigin(origin);
      // 首次自动配对：还没有任何实例信任过本机桥接时，扩展来源可直接换令牌。
      // 威胁模型是「网页 CSRF」——网页带不出 moz-extension:// 的 Origin，所以这道门仍然有效。
      // 一旦有实例，后面的都必须走配对码。
      if (Object.keys(TOKENS).length === 0 && isExt && (body.code === '' || body.code == null || body.auto === true)) {
        const token = mintToken(sid);
        log('首次自动配对 sid=' + sid);
        return send(res, 200, { ok: true, token, sid, auto: true, exp: TOKENS[token].exp });
      }
      if (!pairCodeValid(body.code)) {
        return send(res, 403, { error: 'paircode 无效或已过期', hint: '重新取一个新的 6 位码，或先吊销全部实例后再自动配对' });
      }
      PAIR.used = true;
      store.savePair(PAIR);
      const token = mintToken(sid);
      log('配对成功 sid=' + sid);
      return send(res, 200, { ok: true, token, sid, exp: TOKENS[token].exp });
    }

    const bad = authOk(req);
    if (bad) {
      if (p === '/poll') { state.polling = false; state.lastAuthFailAt = Date.now(); }
      return send(res, 403, { error: bad });
    }

    if (p === '/paircode' && req.method === 'GET') return send(res, 200, currentPairCode());

    if (p === '/tokens' && req.method === 'GET') {
      const list = Object.entries(TOKENS).map(([tok, m]) => ({
        token: tok.slice(0, 10) + '…', sid: m.sid, label: m.label, createdAt: m.createdAt,
        browser: m.browser || '', ver: m.ver || '',
        online: isOnline() && state.lastPollToken === tok,
      }));
      return send(res, 200, { count: list.length, tokens: list });
    }

    if (p === '/rotate' && req.method === 'POST') {
      /* 轮换：拿有效旧令牌换一枚新的，旧令牌当场作废。
       * 扩展在令牌快到期或收到 401 时调用，不用重新输入配对码。 */
      const oldTok = req.headers['x-bb-token'];
      const meta = TOKENS[oldTok] || {};
      delete TOKENS[oldTok];
      store.saveTokens(TOKENS);
      const token = mintToken(meta.sid || state.sid || 'rotate');
      log('令牌轮换 ' + String(oldTok).slice(0, 10) + '… → ' + token.slice(0, 10) + '…');
      return send(res, 200, { ok: true, token, sid: TOKENS[token].sid, exp: TOKENS[token].exp });
    }

    if (p === '/revoke' && req.method === 'POST') {
      let body;
      try { body = await readBody(req); } catch (e) { return send(res, 400, { error: e.message }); }
      const n = revokeToken(body.token);
      if (!n) return send(res, 404, { error: 'token not found' });
      state.lastAuthFailAt = Date.now();
      return send(res, 200, { revoked: n });
    }

    if (p === '/poll' && req.method === 'GET') {
      const sid = url.searchParams.get('sid') || 'default';
      state.sid = sid;
      /* 扩展自报版本：面板上直接显示，装到旧包一眼就能看出来 */
      const ev = url.searchParams.get('v');
      if (ev) state.extVer = String(ev).slice(0, 16);
      const en = url.searchParams.get('n');
      if (en) state.extName = String(en).slice(0, 40);
      /* 给实例起个人能看懂的名字：浏览器 + 版本 + 配对日期。
       * 只改「未命名/旧 ff- 前缀」的，手工重命名过的不覆盖。 */
      const bare = String(req.headers['x-bb-token'] || '');
      if (bare) state.lastPollToken = bare;
      if (bare && TOKENS[bare] && (state.extName || state.extVer)) {
        const cur = String(TOKENS[bare].label || '');
        if (cur.startsWith('未命名实例') || cur.startsWith('ff-')) {
          const name = state.extName || '扩展';
          const ver = state.extVer ? ' ' + state.extVer : '';
          const day = String(TOKENS[bare].createdAt || '').slice(5, 10).replace('-', '/');
          const next = name + ver + (day ? ' · ' + day : '');
          if (next !== cur) {
            TOKENS[bare].label = next;
            TOKENS[bare].browser = state.extName || '';
            TOKENS[bare].ver = state.extVer || '';
            store.saveTokens(TOKENS);
          }
        }
      }
      state.lastSeen = Date.now();
      state.lastPollAt = Date.now();
      state.polling = true;

      if (state.queue.length) {
        const cmd = state.queue.shift();
        state.polling = false;
        return send(res, 200, cmd);
      }
      if (state.waiter) {
        clearTimeout(state.waiter.timer);
        const old = state.waiter;
        state.waiter = null;
        send(old.res, 204);
      }
      state.waiter = {
        res,
        sid,
        timer: setTimeout(() => {
          if (state.waiter && state.waiter.res === res) { state.waiter = null; state.polling = false; }
          send(res, 204);
        }, POLL_WAIT_MS),
      };
      req.on('close', () => {
        if (state.waiter && state.waiter.res === res) {
          clearTimeout(state.waiter.timer);
          state.waiter = null;
          state.polling = false;
        }
      });
      return;
    }

    if (p === '/result' && req.method === 'POST') {
      let body;
      try { body = await readBody(req); } catch (e) { return send(res, 400, { error: e.message }); }
      state.lastSeen = Date.now();
      const rec = state.pending.get(body.id);
      if (!rec) return send(res, 200, { ok: true, ignored: true });
      state.pending.delete(body.id);
      clearTimeout(rec.timer);
      state.served++;
      send(res, 200, { ok: true });
      if (body.ok && body.data && body.data.url) {
        try { state.lastSite = new URL(body.data.url).host; } catch (_) {}
      }
      const safe = body.ok ? sanitizeResult(String(rec.cmd || ''), body.data, rec.args) : undefined;
      /* 结果回来：把刚才那条 pending 补成最终状态（同一位置改写，不追加两条） */
      settleLog(rec.cmd, body.ok, body.ok ? '完成' : String(body.error || '失败'));
      rec.res(body.ok ? { ok: true, data: safe } : { ok: false, error: body.error || 'unknown' });
      return;
    }

    if (p === '/approvals' && req.method === 'GET') {
      return send(res, 200, { pending: grants.pendingList(), grants: grants.list() });
    }
    if (p === '/approve' && req.method === 'POST') {
      let body;
      try { body = await readBody(req); } catch (e) { return send(res, 400, { error: e.message }); }
      const it = grants.pending.get(String(body.id || ''));
      if (!it) return send(res, 404, { error: '没有这条待批请求（可能已超时）' });
      /* 只有 grant 级才接受 remember；面板/HTTP 传 remember 也压不住 call 级 */
      const wantRemember = body.remember !== false && it.kind !== 'call';
      const ok = body.deny === true ? it.deny() : it.approve(wantRemember);
      if (!ok) return send(res, 404, { error: '已经处理过了' });
      log((body.deny === true ? '拒绝' : '批准') + ' ' + it.cmd + ' @ ' + (it.site || '*'));
      return send(res, 200, { ok: true });
    }
    if (p === '/grants/revoke' && req.method === 'POST') {
      let body;
      try { body = await readBody(req); } catch (e) { return send(res, 400, { error: e.message }); }
      if (body.all === true) { grants.revokeAll(); return send(res, 200, { ok: true, all: true }); }
      return send(res, 200, { ok: grants.revoke(String(body.scope || ''), body.site || '*') });
    }

    if (p === '/jar' && req.method === 'GET') return send(res, 200, { hosts: jar.summary(), file: jar.file });
    if (p === '/jar/clear' && req.method === 'POST') {
      let body;
      try { body = await readBody(req); } catch (e) { return send(res, 400, { error: e.message }); }
      return send(res, 200, { cleared: jar.clear(body.host) });
    }
    if (p === '/jar/fetch' && req.method === 'POST') {
      let body;
      try { body = await readBody(req); } catch (e) { return send(res, 400, { error: e.message }); }
      const out = await jarFetch(body.url, body);
      /* 代取回来的正文同样过一遍脱敏规则，避免把页面里的手机号/银行卡带进上下文 */
      if (out.text) out.text = sanitizeResult('page.text', { t: out.text }).t;
      return send(res, 200, out);
    }

    if (p === '/rpc' && req.method === 'POST') {
      let body;
      try { body = await readBody(req); } catch (e) { return send(res, 400, { error: e.message }); }
      const out = await rpcGated(String(body.cmd || ''), body.args || {}, body.timeout);
      if (out.ok) { out.data = sanitizeResult(String(body.cmd || ''), out.data, body.args || {}); return send(res, 200, out); }
      const code = out.error === 'cmd required' ? 400 : 504;
      return send(res, code, out);
    }

    return send(res, 404, { error: 'not found' });
  });

  return new Promise((resolve, reject) => {
    server.once('error', (e) => {
      if (e.code === 'EADDRINUSE') {
        reject(new Error(`端口 ${PORT} 已被占用（可能已有另一个 bridge 在跑）`));
      } else reject(e);
    });
    // 嵌进别人进程时 unref：这个 server 不该成为「进程还不退出」的理由。
    // 独立跑（node bridge.cjs）时不能 unref，否则监听一起来就 exit。
    if (o.unref === true) server.unref();

    server.listen(PORT, HOST, () => {
      log(`browser-bridge v${VERSION} → http://${HOST}:${PORT}`);
      const pc = currentPairCode();
      log(`配对码 ${pc.code}（10 分钟内有效，一次性）`);
      resolve({
        port: PORT,
        state,
        health,
        rpc,
        rpcGated,
        currentPairCode,
        genPairCode,
        revokeToken,
        tokens: () => Object.keys(TOKENS),
        tokensList: () => Object.entries(TOKENS).map(([tok, m]) => ({
          token: tok.slice(0, 10) + '…',
          sid: m.sid, label: m.label, createdAt: m.createdAt,
        })),
        jar: { summary: jar.summary, clear: jar.clear, fetch: jarFetch },
        grants: {
          granted: grants.granted,
          remember: grants.remember,
          rules: SENSITIVE,
          list: grants.list,
          pending: grants.pendingList,
          approve: (id, remember) => { const it = grants.pending.get(String(id)); return it ? it.approve(remember !== false) : false; },
          deny: (id) => { const it = grants.pending.get(String(id)); return it ? it.deny() : false; },
          revoke: grants.revoke,
          revokeAll: grants.revokeAll,
        },
        sink,
        setPair: (code) => { PAIR = { code: String(code), exp: Date.now() + PAIR_TTL_MS, used: false }; store.savePair(PAIR); return PAIR; },
        close: () => new Promise((r) => {
          if (state.waiter) { clearTimeout(state.waiter.timer); try { send(state.waiter.res, 204); } catch (_) {} state.waiter = null; }
          server.close(() => r(null));
          setTimeout(() => r(null), 1500);
        }),
      });
    });
  });
}

module.exports = { startBridge, VERSION, SENSITIVE };

/* ---------- 独立运行 ---------- */

if (require.main === module) {
  startBridge({
    port: process.env.BB_PORT || 8790,
    dataDir: process.env.BB_DATA_DIR || path.join(__dirname, 'data'),
    log: (...a) => console.log(`[${new Date().toISOString()}]`, ...a),
  }).catch((e) => { console.error('启动失败:', e.message); process.exit(1); });

  const shutdown = () => { console.log('bye'); process.exit(0); };
  process.on('SIGTERM', shutdown);
  process.on('SIGINT', shutdown);
}