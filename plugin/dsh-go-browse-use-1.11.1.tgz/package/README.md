# dsh-go-browse-use

把 browser-bridge 服务塞进 dsh-go 引擎，让助手在对话里直接驱动 Firefox。

扩展侧的安装、命令表、安全模型见交付目录的 `browser-bridge/README.md`（那是给用户看的完整版）。

## 它解决什么

没有这个插件时，每次要用桥接都得：

```bash
cd /root/workspace/bb && node bb.js text
```

有了它之后，开关打开时桥接随引擎自启，助手直接调 `browser` 工具：

```
browser({ action: 'tabs' })
browser({ action: 'text', tab: '3' })
browser({ action: 'click', selector: '#submit' })
```

用户不用碰命令行，也不用给每个人写脚本。

## 三块东西

| 组件 | 位置 | 作用 |
|---|---|---|
| 服务核心 | `bridge/bridge.cjs` | HTTP + 长轮询 + 配对 + 吊销。CommonJS，可独立 `node bridge.cjs` |
| 插件入口 | `lib/index.js` | 起服务、注册 `browser` 工具、画面板与胶囊 |
| 浏览器端 | 单独的 `browser-bridge-1.5.0.xpi` | 装进 Firefox，主动 poll 到 127.0.0.1:8790 |

## 端口

**8790**。不用 8765 是因为 Mika 的 MCP 服务已经占了 8765。

## 开关（默认关）

桥接要占本地端口、让扩展一直长轮询，所以**默认关闭**，不常驻。

- 面板里第一块就是开关按钮：「打开桥接 / 关闭桥接」
- 助手也能开关：`browser({action:'on'})` / `browser({action:'off'})`
- 关掉会立刻 `close()` 监听，8790 端口释放；扩展下次轮询失败后按退避停试
- 开关状态落在 `$DSH_HOME/dsh-go/browser-bridge/enabled.json`，重启引擎后保持
- 改动 `enabled.json` 之外的东西都要重启引擎才生效

## 首次使用

1. 引擎里装好本插件、重启引擎（`lib/` 改动必须重启才生效）
2. 面板（插件入口 → 浏览器桥接）里点「打开桥接」，读配对码，或让助手调 `browser({action:'paircode'})`
3. Firefox 装 `browser-bridge-1.5.0.xpi` → 扩展图标 → 状态页输配对码
4. 之后自动重连，不用再配；不用时把开关关掉

## 状态语义

| 面板状态 | 含义 |
|---|---|
| 已关闭 | 开关关着，端口没监听（默认就是这个） |
| 桥接没起来 | 开关开着但服务没起来，端口可能被占 |
| 浏览器待配对 | 服务在跑，但没有任何实例配对过 |
| 已连接 · N | 正常，已服务 N 条命令 |
| 浏览器离线 | 配过对但心跳断了（Firefox 关了，或后台页被系统挂起） |

## 分发

同一个 xpi 发给任何人都行。**令牌不是写死在包里的** —— 每个安装实例首次运行
时用自己的配对码换一对唯一令牌，存在浏览器本地 storage 里。所以：

- 你装 = 你的令牌
- 别人装 = 别人的令牌
- 吊销其中一个不影响其他

配对码 6 位、10 分钟、一次性。所以别人拿不到你的令牌，你也拿不到别人的。

## 令牌存放

`$DSH_HOME/dsh-go/browser-bridge/tokens.json`（0600），配对码在 `paircode.json`。
面板里能逐个吊销，或一次全吊销。

## 安全模型

这一版的重点不是「加个密码」，是把**敏感数据挡在模型上下文之外**。

### 一、分三层，每层管不同的事

| 层 | 管什么 | 不过会怎样 |
|---|---|---|
| 扩展（Firefox 内） | cookie 只出门元数据，真值留在浏览器侧 | 拿到 `cookies.get` 也只有名字/长度/指纹 |
| 桥接（8790） | 命令级授权、cookie 落盘、正文转发、脱敏 | 敏感命令根本进不了队列 |
| 插件（DSH 内） | 走 App 原生审批弹窗 | 用户不点「允许」工具不会执行 |

### 二、cookie 值永远不进上下文

- `cookies.get` 返回 **metadata-only**：`{name, length, fp, domain, path, secure, httpOnly, sameSite, session, expirationDate}`
  —— `fp` 是 FNV-1a 32 位不可逆短哈希，没有 `value` 字段
- 真值走内部命令 `cookies.jar`：扩展把全值交给桥接，桥接 `jar.absorb()`
  写进 `$DSH_HOME/dsh-go/browser-bridge/jar.json`（0600），回给模型的是
  `{host, count, names, bytes}` —— **只有名字和字节数，没有值**
- 需要带 cookie 取页面时用 `jar.fetch(url)`：桥接进程自己发请求、自己落盘，
  页面内容照样过转发与脱敏

### 三、命令分三级授权

| 级别 | 哪些命令 | 行为 |
|---|---|---|
| `auto` | `page.info` `page.links` `page.meta` `cookies.get` `tabs.list` `tab.get` `ping` | 只有元数据，直接过 |
| `grant` | `page.text` `page.html` `page.query` `screenshot` `history.search` `bookmarks.search` `extract.*` | 问一次，按站点记住 1 小时 |
| `call` | `cookies.jar`（导出 cookie 值）、`page.eval`（执行任意代码） | **每次都问**，记住也不算数 |

表里没列的命令一律按 `grant`——宁可多问一次，也不默默放过。

### 四、授权入口是 App 自己的弹窗，不是面板

插件注册 `ctx.on('tools/pre-execute', gate)`，敏感动作返回 `{kind:'ask', ...}`，
`dsh-tools` 的 pipeline 会转成 `ctx.approval.request()` —— App 弹出它自己的
授权框（和 bash 要授权时同一个）。用户点「允许」才继续。

面板里的「待批准的访问」列表保留，但**不是唯一的批准入口**：它是给命令行
`bb.js` 走的路径，以及事后查看/撤销用的。平时面板不用开着。

### 五、正文转发：大块内容落盘不进口袋

`page.text` / `page.html` 超过 2000 字节时，桥接把它写进
`$DSH_HOME/dsh-go/browser-bridge/forward/`，上下文里只留：

```
[已转发到文件，未进入上下文] <path>
N 行 / M 字节
首行：…
```

阈值可用 `BB_FORWARD_THRESHOLD` 调。

### 六、令牌有寿命、能轮换

- 令牌 TTL 默认 24 小时（`BB_TOKEN_TTL_MS`），过期自动清出表
- 扩展遇 `403` 自动 `POST /rotate` 换新令牌，旧令牌当场作废
- `/rotate` 失败才真要重新配对
- 面板能逐个吊销或一次全吊销

### 七、边界：这些做不到

- 只监听 `127.0.0.1`，不出本机；`Origin` 必须 `moz-extension://` 开头（防网页 CSRF）
- 脱敏降低暴露面，**不是加密**：掩码规则确定性，部分值可推回
- `call` 级命令用户点了允许就真的执行了；拒绝或超时才拦得住
- 扩展后台页会被 Android 挂起（实测 74 秒不轮询），这是链路稳定性短板，
  不是安全问题
